#include "draw_thread.h"
#include <algorithm>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <sstream>

namespace worker {

DrawWorker::DrawWorker() = default;

DrawWorker::~DrawWorker() {
    stop();
    join();
}

void DrawWorker::start() {
    if (running_.exchange(true)) return;
    if (thread_.joinable()) thread_.join();
    thread_ = std::thread(&DrawWorker::run, this);
}

void DrawWorker::stop() {
    running_.store(false);
    cv_.notify_all();
}

void DrawWorker::join() {
    if (thread_.joinable()) thread_.join();
}

bool DrawWorker::is_running() const {
    return running_.load();
}

void DrawWorker::push(DrawFrame df) {
    {
        std::lock_guard<std::mutex> lk(slot_mutex_);
        latest_  = std::move(df);
        has_new_ = true;
    }
    cv_.notify_one();
}

void DrawWorker::run() {
    const std::string kWindow = "ControlView";
    cv::namedWindow(kWindow, cv::WINDOW_NORMAL);

    auto last_fps_time = std::chrono::steady_clock::now();
    int frame_count = 0;

    while (running_.load()) {
        DrawFrame df;
        {
            std::unique_lock<std::mutex> lk(slot_mutex_);
            cv_.wait_for(lk, std::chrono::milliseconds(10),
                         [this] { return has_new_ || !running_.load(); });
            if (!has_new_) continue;
            df       = std::move(latest_);
            has_new_ = false;
            // 🔥 丢弃积压帧：只渲染最新一帧
            while (has_new_) {
                df = std::move(latest_);
                has_new_ = false;
            }
        }

        if (df.frame.empty()) continue;

        cv::Mat& canvas = df.frame;
        renderFrame(df, canvas);

        // ── FPS 统计 ──
        frame_count++;
        auto now = std::chrono::steady_clock::now();
        double elapsed = std::chrono::duration<double>(now - last_fps_time).count();
        if (elapsed >= 3.0) {
            double fps = frame_count / elapsed;
            std::cout << "[DrawWorker] FPS: " << std::fixed << std::setprecision(1) << fps << std::endl;
            frame_count = 0;
            last_fps_time = now;
        }

        cv::imshow(kWindow, canvas);

        // 增加 waitKey 到 5ms 减少 CPU 争抢（嵌入式软渲染需要更多时间）
        if (cv::waitKey(5) == 'q') {
            running_.store(false);
            break;
        }
    }

    cv::destroyAllWindows();
    std::cout << "[DrawWorker] thread stopped" << std::endl;
}

void DrawWorker::renderFrame(const DrawFrame& df, cv::Mat& canvas) {
    // ── 持久化：跟踪框无数据时用上次有效数据防闪烁 ──
    // 注意：检测框不持久化！持久化旧检测框会导致框位置滞后（"剥离"感）
    // 跟踪框过期清理：超过3秒无新框，清除旧框（防止目标丢失后框残留）
    constexpr double kTrackExpireSec = 3.0;
    if (!df.tracks.empty()) {
        last_tracks_ = df.tracks;
        last_tracks_time_ = std::chrono::steady_clock::now();
    } else if (!last_tracks_.empty()) {
        auto elapsed = std::chrono::duration<double>(
            std::chrono::steady_clock::now() - last_tracks_time_).count();
        if (elapsed > kTrackExpireSec) {
            last_tracks_.clear();
        }
    }
    const auto& tracks = df.tracks.empty() ? last_tracks_ : df.tracks;
    const auto& detections = df.detections;

    // 1. 绘制检测框（蓝色细框），跳过已被跟踪的目标
    for (const auto& det : detections) {
        const cv::Rect& det_box = det.box;

        // 检查是否已有跟踪框覆盖（重叠 IoU > 0.3 则跳过，避免闪烁双框）
        bool already_tracked = false;
        for (const auto& track : tracks) {
            if (track.tlwh.size() < 4) continue;
            cv::Rect track_box(
                static_cast<int>(track.tlwh[0]),
                static_cast<int>(track.tlwh[1]),
                static_cast<int>(track.tlwh[2]),
                static_cast<int>(track.tlwh[3])
            );
            cv::Rect inter = det_box & track_box;
            if (inter.area() > 0) {
                float iou = static_cast<float>(inter.area()) /
                            (det_box.area() + track_box.area() - inter.area());
                if (iou > 0.3f) {
                    already_tracked = true;
                    break;
                }
            }
        }
        if (already_tracked) continue;

        cv::rectangle(canvas, det_box, cv::Scalar(255, 0, 0), 2);  // 蓝色检测框

        const std::string label = det.class_name + " " +
            std::to_string(static_cast<int>(det.conf * 100)) + "%";
        cv::putText(canvas, label,
                    cv::Point(det_box.x, std::max(det_box.y - 5, 0)),
                    cv::FONT_HERSHEY_SIMPLEX, 0.55, cv::Scalar(255, 0, 0), 2);
    }
    
    // 2. 绘制跟踪框（绿色，锁定目标红色）+ EMA 平滑防抖
    for (const auto& track : tracks) {
        if (track.tlwh.size() < 4) continue;

        constexpr float kBoxEmaAlpha = 0.15f;  // 框平滑系数（降低减少抖动）
        const int tid = track.track_id;
        float raw_cx = track.tlwh[0] + track.tlwh[2] * 0.5f;
        float raw_cy = track.tlwh[1] + track.tlwh[3] * 0.5f;
        float raw_w  = track.tlwh[2];
        float raw_h  = track.tlwh[3];

        // EMA 平滑
        auto it = track_smooth_.find(tid);
        if (it == track_smooth_.end()) {
            track_smooth_[tid] = {raw_cx, raw_cy, raw_w, raw_h};
            it = track_smooth_.find(tid);
        } else {
            it->second.cx = kBoxEmaAlpha * raw_cx + (1.f - kBoxEmaAlpha) * it->second.cx;
            it->second.cy = kBoxEmaAlpha * raw_cy + (1.f - kBoxEmaAlpha) * it->second.cy;
            it->second.w  = kBoxEmaAlpha * raw_w  + (1.f - kBoxEmaAlpha) * it->second.w;
            it->second.h  = kBoxEmaAlpha * raw_h  + (1.f - kBoxEmaAlpha) * it->second.h;
        }

        const cv::Rect box(
            static_cast<int>(it->second.cx - it->second.w * 0.5f),
            static_cast<int>(it->second.cy - it->second.h * 0.5f),
            static_cast<int>(it->second.w),
            static_cast<int>(it->second.h)
        );

        // 锁定目标用红色加粗，其他用绿色
        const bool is_target = (df.target_track_id >= 0 && track.track_id == df.target_track_id);
        const cv::Scalar color = is_target ? cv::Scalar(0, 0, 255) : cv::Scalar(0, 255, 0);
        const int thickness = is_target ? 3 : 2;
        cv::rectangle(canvas, box, color, thickness);

        // 显示实际类别名 + track_id
        static const std::vector<std::string> kClassNames = {
            "person","bicycle","car","motorbike","aeroplane","bus","train","truck","boat",
            "traffic light","fire hydrant","stop sign","parking meter","bench","bird","cat",
            "dog","horse","sheep","cow","elephant","bear","zebra","giraffe","backpack",
            "umbrella","handbag","tie","suitcase","frisbee","skis","snowboard","sports ball",
            "kite","baseball bat","baseball glove","skateboard","surfboard","tennis racket",
            "bottle","wine glass","cup","fork","knife","spoon","bowl","banana","apple",
            "sandwich","orange","broccoli","carrot","hot dog","pizza","donut","cake","chair",
            "sofa","pottedplant","bed","diningtable","toilet","tvmonitor","laptop","mouse",
            "remote","keyboard","cell phone","microwave","oven","toaster","sink","refrigerator",
            "book","clock","vase","scissors","teddy bear","hair drier","toothbrush"
        };
        std::string label;
        if (track.label >= 0 && track.label < static_cast<int>(kClassNames.size())) {
            label = kClassNames[track.label] + " ID:" + std::to_string(track.track_id);
        } else {
            label = "cls" + std::to_string(track.label) + " ID:" + std::to_string(track.track_id);
        }
        cv::putText(canvas, label,
                    cv::Point(box.x, std::max(box.y - 5, 0)),
                    cv::FONT_HERSHEY_SIMPLEX, 0.55, color, 2);
    }

    cv::putText(canvas, df.mode_label,
                cv::Point(10, 30),
                cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(0, 255, 255), 2);

    std::ostringstream zoom_ss;
    const float display_zoom = df.has_zoom ? df.zoom_value : 1.0f;
    zoom_ss << std::fixed << std::setprecision(1) << "ZOOM: " << display_zoom;
    cv::putText(canvas, zoom_ss.str(),
                cv::Point(10, 60),
                cv::FONT_HERSHEY_SIMPLEX, 0.75, cv::Scalar(255, 255, 0), 2);

    // 3. 海天线文字标注（叠在线上，左侧）+ EMA 平滑防抖
    if (df.horizon_y >= 0) {
        constexpr float kEmaAlpha = 0.25f;  // 平滑系数，越小越平滑
        if (smoothed_horizon_y_ < 0.f) {
            smoothed_horizon_y_ = static_cast<float>(df.horizon_y);
        } else {
            smoothed_horizon_y_ = kEmaAlpha * static_cast<float>(df.horizon_y)
                                + (1.f - kEmaAlpha) * smoothed_horizon_y_;
        }
        int hz_y = static_cast<int>(std::round(smoothed_horizon_y_));

        // 文字居中叠在海天线上（左侧，黑底黄字便于辨识）
        std::string hz_label = "HORIZON";
        int baseline = 0;
        cv::Size text_sz = cv::getTextSize(hz_label, cv::FONT_HERSHEY_SIMPLEX, 0.5, 1, &baseline);
        // putText 的 y 是基线；让文字垂直中心 = hz_y
        int text_y = hz_y + text_sz.height / 2;
        text_y = std::clamp(text_y, text_sz.height + 2, canvas.rows - 2);
        cv::rectangle(canvas,
                      cv::Point(2, text_y - text_sz.height),
                      cv::Point(text_sz.width + 6, text_y + baseline),
                      cv::Scalar(0, 0, 0), cv::FILLED);
        cv::putText(canvas, hz_label,
                    cv::Point(4, text_y),
                    cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(0, 255, 255), 1);
    }
}

}  // namespace worker
