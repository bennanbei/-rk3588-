#pragma once

#include <atomic>
#include <condition_variable>
#include <mutex>
#include <queue>
#include <string>
#include <thread>
#include <vector>
#include <unordered_map>
#include <opencv2/opencv.hpp>
#include "../../algorithm/bytetrack/include/STrack.h"
#include "../../algorithm/detection/yolo_detect_rknn_v2.h"

namespace worker {

class DrawWorker {
public:
    using Detection = algorithm::YoloDetectorRKNNV2::Detection;
    
    struct DrawFrame {
        cv::Mat             frame;
        std::vector<STrack> tracks;           // 跟踪结果
        std::vector<Detection> detections;    // 所有检测结果（用于画框）
        int                 target_track_id{-1};
        std::string         mode_label;
        float               zoom_value{0.0f};
        bool                has_zoom{false};
        int                 horizon_y{-1};    // 海天线 y 坐标，-1 表示无
    };

    DrawWorker();
    ~DrawWorker();

    void start();
    void stop();
    void join();

    bool is_running() const;

    void push(DrawFrame df);

private:
    void run();
    void renderFrame(const DrawFrame& df, cv::Mat& canvas);

    std::atomic<bool>       running_{false};
    std::thread             thread_;
    std::mutex              slot_mutex_;
    std::condition_variable cv_;
    DrawFrame               latest_;
    bool                    has_new_{false};

    // ── 防闪烁平滑状态 ───────────────────────────────────
    float smoothed_horizon_y_{-1.f};  // EMA 平滑后的海天线 y

    // ── 跟踪框持久化（避免丢帧闪烁，超过3秒无新框则清理） ──────────────
    std::vector<STrack>     last_tracks_;       // 上次有效跟踪框
    std::chrono::steady_clock::time_point last_tracks_time_;  // 上次更新时刻

    // ── 跟踪框 EMA 平滑 ─────────────────────────────────
    struct SmoothedBox {
        float cx, cy, w, h;
    };
    std::unordered_map<int, SmoothedBox> track_smooth_;  // track_id → 平滑框
};

}  // namespace worker
