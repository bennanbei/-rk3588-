/**
 * RK3588 实机光电球跟踪程序
 * 连接真实光电球，使用 RKNN 检测和海天线分割
 */

#include <iostream>
#include <memory>
#include <mutex>
#include <atomic>
#include <chrono>
#include <opencv2/opencv.hpp>

// 视频流和云台接口
#include "../abstract_camer/IVideoStream.h"
#include "../abstract_camer/IGimbal.h"
#include "../ruichuan/video_steam/ruichuan_video_stream_adapter.h"
#include "../ruichuan/driver/ruichuan_driver.h"
#include "../ruichuan/driver/ruichuan_gimbal_adapter.h"

// RKNN 检测和分割
#include "../algorithm/detection/yolo_detect_rknn_v2.h"
#include "../algorithm/water_seg/seg_control/seg_control_rknn.h"

using namespace algorithm;

class RK3588LiveTracking {
public:
    struct Config {
        std::string rtsp_url = "rtsp://192.168.144.25:8554/video1";
        std::string yolo_model = "../model/seaship.rknn";        // 海上目标检测（船/人）
        std::string horizon_model = "../model/wasr_mobilenet.rknn"; // 海天线语义分割
        bool enable_detection = true;
        bool enable_horizon = true;
        bool enable_gimbal_control = false;  // 是否启用自动云台控制
        bool enable_display = true;  // 是否启用显示（SSH 环境设为 false）
        float detection_interval = 0.1f;  // 检测间隔（秒）
    };

public:
    RK3588LiveTracking(const Config& cfg) : config_(cfg) {}
    
    bool initialize() {
        std::cout << "=== RK3588 实机跟踪系统初始化 ===" << std::endl;
        
        // 1. 创建视频流
        std::cout << "连接视频流: " << config_.rtsp_url << std::endl;
        video_stream_ = std::make_shared<ruichuan::RuichuanVideoStreamAdapter>(config_.rtsp_url);
        
        // 2. 创建驱动和云台
        std::cout << "初始化云台驱动..." << std::endl;
        driver_ = std::make_shared<ruichuan::RuichuanDriver>();
        gimbal_ = std::make_shared<ruichuan::RuichuanGimbalAdapter>(driver_);
        
        // 3. 初始化 YOLO 检测器
        if (config_.enable_detection) {
            std::cout << "加载 YOLO 模型: " << config_.yolo_model << std::endl;
            YoloDetectorRKNNV2::Config yolo_cfg;
            yolo_cfg.conf_thresh = 0.25f;
            yolo_cfg.iou_thresh = 0.45f;
            yolo_cfg.target_classes = {0, 8};  // person(0) + boat(8) 海上目标
            
            yolo_detector_ = std::make_unique<YoloDetectorRKNNV2>(yolo_cfg);
            if (!yolo_detector_->load_model(config_.yolo_model)) {
                std::cerr << "YOLO 模型加载失败" << std::endl;
                return false;
            }
            std::cout << "YOLO 检测器初始化成功" << std::endl;
        }
        
        // 4. 初始化海天线分割
        if (config_.enable_horizon) {
            std::cout << "加载海天线模型: " << config_.horizon_model << std::endl;
            seg_control_rknn::Config seg_cfg;
            seg_cfg.model_path = config_.horizon_model;
            seg_cfg.infer_interval_sec = 1.0f;
            seg_cfg.enable_on_start = true;
            
            horizon_detector_ = std::make_unique<seg_control_rknn>(seg_cfg);
            std::cout << "海天线分割器初始化成功" << std::endl;
        }
        
        return true;
    }
    
    void run() {
        std::cout << "\n=== 启动实机跟踪 ===" << std::endl;
        std::cout << "按 'q' 退出, 'c' 云台归中, 'z/x' 调整焦距" << std::endl;
        
        // 设置视频帧回调
        video_stream_->set_on_frame([this](const cv::Mat& frame) {
            std::lock_guard<std::mutex> lock(frame_mutex_);
            latest_frame_ = frame.clone();
            has_new_frame_ = true;
        });
        
        // 启动视频流
        if (!video_stream_->start()) {
            std::cerr << "视频流启动失败" << std::endl;
            return;
        }
        
        // 启动云台数据流
        gimbal_->start();
        
        // 主处理循环
        auto last_detect_time = std::chrono::steady_clock::now();
        int frame_count = 0;
        
        while (running_) {
            // 获取最新帧
            cv::Mat frame;
            {
                std::lock_guard<std::mutex> lock(frame_mutex_);
                if (!has_new_frame_ || latest_frame_.empty()) {
                    std::this_thread::sleep_for(std::chrono::milliseconds(10));
                    continue;
                }
                frame = latest_frame_.clone();
                has_new_frame_ = false;
            }
            
            frame_count++;
            cv::Mat display = frame.clone();
            
            // 定期执行检测
            auto now = std::chrono::steady_clock::now();
            auto elapsed = std::chrono::duration<float>(now - last_detect_time).count();
            
            if (elapsed >= config_.detection_interval) {
                // YOLO 目标检测
                if (config_.enable_detection && yolo_detector_) {
                    auto detections = yolo_detector_->detect(frame);
                    
                    // 保存检测结果
                    {
                        std::lock_guard<std::mutex> lock(detection_mutex_);
                        latest_detections_ = detections;
                    }
                    
                    // 绘制检测框
                    for (const auto& det : detections) {
                        cv::rectangle(display, det.box, cv::Scalar(0, 255, 0), 2);
                        std::string label = det.class_name + " " + 
                                          std::to_string(int(det.conf * 100)) + "%";
                        cv::putText(display, label, 
                                   cv::Point(det.box.x, det.box.y - 10),
                                   cv::FONT_HERSHEY_SIMPLEX, 0.5, 
                                   cv::Scalar(0, 255, 0), 2);
                    }
                    
                    // 如果启用云台控制且检测到目标
                    if (config_.enable_gimbal_control && !detections.empty()) {
                        controlGimbal(detections[0], frame.cols, frame.rows);
                    }
                }
                
                // 海天线分割
                if (config_.enable_horizon && horizon_detector_) {
                    horizon_detector_->submit_frame(frame);
                }
                
                last_detect_time = now;
            }
            
            // 绘制海天线
            if (horizon_detector_ && horizon_detector_->has_result()) {
                horizon_detector_->draw_water_area(display);
                
                // 获取控制命令
                auto cmd = horizon_detector_->get_control_command();
                if (cmd.valid) {
                    std::string horizon_info = "Horizon: y=" + std::to_string(cmd.horizon_y) +
                                              " dev=" + std::to_string(cmd.deviation_px) + "px";
                    cv::putText(display, horizon_info, cv::Point(10, 60),
                               cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 255, 255), 2);
                }
            }
            
            // 显示云台信息
            auto gimbal_data = gimbal_->latest();
            std::string gimbal_info = "Zoom: " + std::to_string(gimbal_data.zoom_value).substr(0, 4) + "x " +
                                     "Pitch: " + std::to_string(gimbal_data.pitch).substr(0, 5) + " " +
                                     "Yaw: " + std::to_string(gimbal_data.yaw).substr(0, 5);
            cv::putText(display, gimbal_info, cv::Point(10, 30),
                       cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(255, 255, 0), 2);
            
            // 显示帧率
            cv::putText(display, "Frame: " + std::to_string(frame_count), 
                       cv::Point(10, display.rows - 10),
                       cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(255, 255, 255), 2);
            
            // 显示画面
            if (config_.enable_display) {
                cv::imshow("RK3588 Live Tracking", display);
                
                // 处理按键
                int key = cv::waitKey(1);
                if (key == 'q' || key == 27) {
                    running_ = false;
                } else if (key == 'c') {
                    std::cout << "云台归中..." << std::endl;
                    gimbal_->center();
                } else if (key == 'z') {
                    std::cout << "焦距放大..." << std::endl;
                    gimbal_->zoom_manual(1);
                } else if (key == 'x') {
                    std::cout << "焦距缩小..." << std::endl;
                    gimbal_->zoom_manual(-1);
                } else if (key == 's') {
                    std::cout << "停止焦距调整..." << std::endl;
                    gimbal_->zoom_manual(0);
                } else if (key == 't') {
                    config_.enable_gimbal_control = !config_.enable_gimbal_control;
                    std::cout << "自动云台控制: " << (config_.enable_gimbal_control ? "开启" : "关闭") << std::endl;
                }
            } else {
                // 无显示模式，定期打印状态
                if (frame_count % 30 == 0) {
                    std::cout << "Frame: " << frame_count << " | Running..." << std::endl;
                }
            }
        }
        
        // 清理
        video_stream_->stop();
        gimbal_->stop();
        cv::destroyAllWindows();
        
        std::cout << "系统已停止" << std::endl;
    }
    
    void stop() {
        running_ = false;
    }

private:
    void controlGimbal(const YoloDetectorRKNNV2::Detection& target, int frame_w, int frame_h) {
        // 计算目标中心相对于画面中心的偏移
        int target_center_x = target.box.x + target.box.width / 2;
        int target_center_y = target.box.y + target.box.height / 2;
        
        int frame_center_x = frame_w / 2;
        int frame_center_y = frame_h / 2;
        
        int offset_x = target_center_x - frame_center_x;
        int offset_y = target_center_y - frame_center_y;
        
        // 死区
        const int deadzone = 50;
        if (std::abs(offset_x) < deadzone && std::abs(offset_y) < deadzone) {
            return;
        }
        
        // 计算云台转动速度（简单比例控制）
        int8_t yaw_speed = 0;
        int8_t pitch_speed = 0;
        
        if (std::abs(offset_x) > deadzone) {
            yaw_speed = std::clamp(offset_x / 100, -5, 5);
        }
        
        if (std::abs(offset_y) > deadzone) {
            pitch_speed = std::clamp(offset_y / 100, -5, 5);
        }
        
        // 发送云台控制命令
        gimbal_->gimbal_turn(yaw_speed, pitch_speed);
    }

private:
    Config config_;
    std::atomic<bool> running_{true};
    
    // 视频流和云台
    std::shared_ptr<abstract_camer::IVideoStream> video_stream_;
    std::shared_ptr<ruichuan::RuichuanDriver> driver_;
    std::shared_ptr<abstract_camer::IGimbal> gimbal_;
    
    // 检测和分割
    std::unique_ptr<YoloDetectorRKNNV2> yolo_detector_;
    std::unique_ptr<seg_control_rknn> horizon_detector_;
    
    // 帧缓冲
    std::mutex frame_mutex_;
    cv::Mat latest_frame_;
    std::atomic<bool> has_new_frame_{false};
    
    // 检测结果
    std::mutex detection_mutex_;
    std::vector<YoloDetectorRKNNV2::Detection> latest_detections_;
};

int main(int argc, char** argv) {
    RK3588LiveTracking::Config config;
    
    // 解析命令行参数
    int arg_idx = 1;
    while (arg_idx < argc) {
        std::string arg = argv[arg_idx];
        if (arg == "--no-display") {
            config.enable_display = false;
            std::cout << "无显示模式（适合 SSH 环境）" << std::endl;
            arg_idx++;
        } else if (arg_idx == 1) {
            config.rtsp_url = argv[arg_idx];
            arg_idx++;
        } else if (arg_idx == 2) {
            config.yolo_model = argv[arg_idx];
            arg_idx++;
        } else if (arg_idx == 3) {
            config.horizon_model = argv[arg_idx];
            arg_idx++;
        } else {
            arg_idx++;
        }
    }
    
    std::cout << "=== RK3588 实机光电球跟踪系统 ===" << std::endl;
    std::cout << "RTSP: " << config.rtsp_url << std::endl;
    std::cout << "YOLO: " << config.yolo_model << std::endl;
    std::cout << "Horizon: " << config.horizon_model << std::endl;
    std::cout << "Display: " << (config.enable_display ? "enabled" : "disabled") << std::endl;
    
    RK3588LiveTracking tracker(config);
    
    if (!tracker.initialize()) {
        std::cerr << "初始化失败" << std::endl;
        return -1;
    }
    
    tracker.run();
    
    return 0;
}
