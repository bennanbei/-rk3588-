#include "track_thread.h"

#include <chrono>
#include <iostream>
#include <thread>
#include <sched.h>
#include <pthread.h>

namespace worker {

TrackingWorker::TrackingWorker(FrameQueue& frame_queue,
                               algorithm::YoloDetectorRKNNV2& detector,
                               abstract_camer::IGimbal& gimbal,
                               TargetMatcher& target_matcher,
                               float cnn_threshold)
    : frame_queue_(frame_queue),
      detector_(detector),
      gimbal_(gimbal),
      target_matcher_(target_matcher),
      cnn_threshold_(cnn_threshold) {}

TrackingWorker::~TrackingWorker() {
    stop();
    join();
}

void TrackingWorker::start() {
    if (running_.load()) {
        return;
    }
    running_.store(true);
    thread_ = std::thread(&TrackingWorker::run, this);
}

void TrackingWorker::stop() {
    running_.store(false);
}

void TrackingWorker::join() {
    if (thread_.joinable()) {
        thread_.join();
    }
}

bool TrackingWorker::is_running() const {
    return running_.load();
}

bool TrackingWorker::getResult(SharedTrackingResult& out) {
    std::lock_guard<std::mutex> lock(result_mutex_);
    if (!result_.valid) {
        return false;
    }

    out.frame = result_.frame;
    out.detections = result_.detections;
    out.tracks = result_.tracks;
    out.seq = result_.seq;
    out.valid = result_.valid;
    return true;
}

bool TrackingWorker::getResultIfNew(uint64_t last_seq, SharedTrackingResult& out) {
    std::lock_guard<std::mutex> lock(result_mutex_);
    if (!result_.valid || result_.seq <= last_seq) {
        return false;
    }

    out.frame = result_.frame;
    out.detections = result_.detections;
    out.tracks = result_.tracks;
    out.seq = result_.seq;
    out.valid = result_.valid;
    return true;
}

void TrackingWorker::run() {
    // 设置线程亲和性：绑定到A76大核（CPU 4-7）以提高实时性
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(4, &cpuset);  // A76 大核
    CPU_SET(5, &cpuset);
    CPU_SET(6, &cpuset);
    CPU_SET(7, &cpuset);
    pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset);
    
    // 设置实时调度优先级
    struct sched_param param;
    param.sched_priority = 50;
    pthread_setschedparam(pthread_self(), SCHED_FIFO, &param);
    
    cv::Mat frame;

    while (running_.load()) {
        // ---------- 1. 从队列取最新帧（带超时等待，避免轮询空转）----------
        if (!frame_queue_.pop(frame, 5)) {
            continue;
        }

        if (frame.empty()) {
            continue;
        }

        // ---------- 2. YOLO 检测 ----------
        auto t0 = std::chrono::high_resolution_clock::now();
        auto detections = detector_.detect(frame);
        auto t1 = std::chrono::high_resolution_clock::now();
        double det_ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        // ---------- 3. CNN 模板匹配过滤：最高相似度 + IoU 粘性防跳变 ----------
        std::vector<ObjectWithFeature> objects;

        const bool has_templates = target_matcher_.hasTemplate();
        int cnn_passed = 0;

        // 遍历所有检测，记录每个候选的 CNN 相似度
        struct Candidate {
            int idx;
            float cnn_sim;
        };
        std::vector<Candidate> candidates;

        for (size_t i = 0; i < detections.size(); i++) {
            const auto& det = detections[i];
            if (det.class_id != 0 && det.class_id != 8 && det.class_id != 64) continue;

            float sim = 0.0f;
            if (has_templates) {
                cv::Rect roi = det.box;
                roi.x = std::max(0, roi.x);
                roi.y = std::max(0, roi.y);
                roi.width  = std::min(roi.width,  frame.cols - roi.x);
                roi.height = std::min(roi.height, frame.rows - roi.y);
                if (roi.width <= 0 || roi.height <= 0) continue;

                sim = target_matcher_.computeSimilarity(frame(roi));
                if (sim < cnn_threshold_) continue;
            }
            candidates.push_back({static_cast<int>(i), sim});
        }

        // 选择最优候选：优先与上一帧 IoU 匹配的，避免在两条船之间跳变
        int best_idx = -1;
        float best_sim = 0.0f;

        if (!candidates.empty()) {
            if (prev_best_valid_) {
                // 在 IoU 匹配的候选中选 CNN 最高的
                int iou_best_idx = -1;
                float iou_best_score = 0.0f;

                for (const auto& c : candidates) {
                    const auto& det = detections[c.idx];
                    cv::Rect_<float> cur(
                        static_cast<float>(det.box.x), static_cast<float>(det.box.y),
                        static_cast<float>(det.box.width), static_cast<float>(det.box.height));

                    float inter_w = std::min(prev_best_box_.x + prev_best_box_.width,  cur.x + cur.width)
                                  - std::max(prev_best_box_.x, cur.x);
                    float inter_h = std::min(prev_best_box_.y + prev_best_box_.height, cur.y + cur.height)
                                  - std::max(prev_best_box_.y, cur.y);
                    if (inter_w <= 0 || inter_h <= 0) continue;

                    float inter = inter_w * inter_h;
                    float area1 = prev_best_box_.width * prev_best_box_.height;
                    float area2 = cur.width * cur.height;
                    float iou = inter / (area1 + area2 - inter);

                    if (iou > 0.35f) {  // IoU 匹配的候选（提高门槛防抖动）
                        float score = c.cnn_sim * 0.4f + iou * 0.6f;
                        if (score > iou_best_score) {
                            iou_best_score = score;
                            iou_best_idx = c.idx;
                            best_sim = c.cnn_sim;
                        }
                    }
                }

                if (iou_best_idx >= 0) {
                    // 有 IoU 匹配的候选 → 粘住
                    best_idx = iou_best_idx;
                } else {
                    // 无 IoU 匹配 → 纯 CNN 最高（需超过粘性门槛才切换）
                    best_idx = candidates[0].idx;
                    best_sim = candidates[0].cnn_sim;
                    for (const auto& c : candidates) {
                        if (c.cnn_sim > best_sim) {
                            best_sim = c.cnn_sim;
                            best_idx = c.idx;
                        }
                    }
                }
            } else {
                // 首次：纯 CNN 最高
                best_idx = candidates[0].idx;
                best_sim = candidates[0].cnn_sim;
                for (const auto& c : candidates) {
                    if (c.cnn_sim > best_sim) {
                        best_sim = c.cnn_sim;
                        best_idx = c.idx;
                    }
                }
            }
        }

        // 仅将最优检测送入 ByteTrack
        if (best_idx >= 0) {
            const auto& det = detections[best_idx];
            cnn_passed = 1;

            // 更新上一帧记忆
            prev_best_box_ = cv::Rect_<float>(
                static_cast<float>(det.box.x), static_cast<float>(det.box.y),
                static_cast<float>(det.box.width), static_cast<float>(det.box.height));
            prev_best_valid_ = true;

            ObjectWithFeature obj;
            obj.rect = cv::Rect_<float>(
                static_cast<float>(det.box.x),
                static_cast<float>(det.box.y),
                static_cast<float>(det.box.width),
                static_cast<float>(det.box.height)
            );
            obj.label = det.class_id;
            obj.prob = det.conf;
            obj.feature = AppearanceFeature::extractHistFeature(frame, det.box);
            objects.push_back(obj);
        }

        // ---------- 4. ByteTrack 跟踪（只跟踪人）----------
        auto t2 = std::chrono::high_resolution_clock::now();
        std::vector<STrack> tracks = tracker_.updateWithFeature(objects);
        auto t3 = std::chrono::high_resolution_clock::now();
        double track_ms = std::chrono::duration<double, std::milli>(t3 - t2).count();

        // ---------- 5. 写入共享结果 ----------
        {
            std::lock_guard<std::mutex> lock(result_mutex_);
            result_.frame = frame;
            result_.detections = detections;
            result_.tracks = tracks;
            result_.seq++;
            result_.valid = true;
        }

        // ---------- 6. 调试输出 ----------
        static int dbg = 0;
        if (dbg++ % 30 == 0) {
            std::cout << "[TrackingWorker] det=" << det_ms
                      << " ms, track=" << track_ms
                      << " ms, dets=" << detections.size()
                      << ", cnn_pass=" << cnn_passed
                      << ", tracks=" << tracks.size();
            if (!detections.empty()) {
                std::cout << ", first_det: class=" << detections[0].class_id
                          << " conf=" << detections[0].conf;
            }
            std::cout << std::endl;
        }
    }

    std::cout << "[TrackingWorker] thread stopped" << std::endl;
}

}  // namespace worker