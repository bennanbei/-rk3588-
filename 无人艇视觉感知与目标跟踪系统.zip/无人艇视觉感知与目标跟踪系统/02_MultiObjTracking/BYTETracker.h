#pragma once

#include "STrack.h"

struct Object
{
    cv::Rect_<float> rect;
    int label;
    float prob;
};

// 带外观特征的检测结果
struct ObjectWithFeature
{
    cv::Rect_<float> rect;
    int label;
    float prob;
    cv::Mat feature;  // 外观特征
};

class BYTETracker
{
public:
	BYTETracker(int frame_rate = 30, int track_buffer = 200);
	~BYTETracker();

	// 原始接口 (仅IoU匹配)
	vector<STrack> update(const vector<Object>& objects);
	
	// 新接口：带外观特征的更新 (IoU + 外观特征混合匹配)
	vector<STrack> updateWithFeature(const vector<ObjectWithFeature>& objects);
	
	Scalar get_color(int idx);

private:
	vector<STrack*> joint_stracks(vector<STrack*> &tlista, vector<STrack> &tlistb);
	vector<STrack> joint_stracks(vector<STrack> &tlista, vector<STrack> &tlistb);

	vector<STrack> sub_stracks(vector<STrack> &tlista, vector<STrack> &tlistb);
	void remove_duplicate_stracks(vector<STrack> &resa, vector<STrack> &resb, vector<STrack> &stracksa, vector<STrack> &stracksb);

	void linear_assignment(vector<vector<float> > &cost_matrix, int cost_matrix_size, int cost_matrix_size_size, float thresh,
	vector<vector<int> > &matches, vector<int> &unmatched_a, vector<int> &unmatched_b);
	vector<vector<float> > iou_distance(vector<STrack*> &atracks, vector<STrack> &btracks, int &dist_size, int &dist_size_size);
	vector<vector<float> > iou_distance(vector<STrack> &atracks, vector<STrack> &btracks);
	vector<vector<float> > ious(vector<vector<float> > &atlbrs, vector<vector<float> > &btlbrs);
	
	// 外观特征距离 (1 - 相似度)
	vector<vector<float> > appearance_distance(vector<STrack*> &atracks, vector<STrack> &btracks, int &dist_size, int &dist_size_size);
	
	// 融合距离: lambda * iou_dist + (1-lambda) * appearance_dist
	vector<vector<float> > fused_distance(vector<STrack*> &atracks, vector<STrack> &btracks, int &dist_size, int &dist_size_size);

	double lapjv(const vector<vector<float> > &cost, vector<int> &rowsol, vector<int> &colsol, 
	bool extend_cost = false, float cost_limit = LONG_MAX, bool return_cost = true);

private:

	float track_thresh;
	float high_thresh;
	float match_thresh;
	float appearance_thresh;  // 外观匹配阈值
	float lambda_;            // IoU与外观特征融合权重
	int frame_id;
	int max_time_lost;

	vector<STrack> tracked_stracks;
	vector<STrack> lost_stracks;
	vector<STrack> removed_stracks;
	byte_kalman::KalmanFilter kalman_filter;
	
	// 临时存储检测特征，用于更新轨迹特征
	vector<cv::Mat> det_features_;
};