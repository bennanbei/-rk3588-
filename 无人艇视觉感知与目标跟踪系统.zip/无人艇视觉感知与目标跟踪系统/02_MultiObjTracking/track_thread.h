#pragma once

#include <atomic>
#include <thread>
#include <mutex>
#include <vector>
#include <cstdint>
#include <opencv2/opencv.hpp>

#include "../../system/frame_queue.h"
#include "../../algorithm/detection/yolo_detect_rknn_v2.h"
#include "../../algorithm/bytetrack/include/BYTETracker.h"
#include "../../algorithm/reid/TargetMatcher.h"
#include "../../abstract_camer/IGimbal.h"

namespace worker {

class TrackingWorker {
public:
    struct SharedTrackingResult {
        cv::Mat frame;
        std::vector<algorithm::YoloDetectorRKNNV2::Detection> detections;
        std::vector<STrack> tracks;
        uint64_t seq = 0;
        bool valid = false;
    };

public:
    TrackingWorker(FrameQueue& frame_queue,
                   algorithm::YoloDetectorRKNNV2& detector,
                   abstract_camer::IGimbal& gimbal,
                   TargetMatcher& target_matcher,
                   float cnn_threshold = 0.50f);

    ~TrackingWorker();

    void start();
    void stop();
    void join();

    bool is_running() const;

    bool getResult(SharedTrackingResult& out);
    bool getResultIfNew(uint64_t last_seq, SharedTrackingResult& out);

private:
    void run();
    std::atomic<bool> running_{false};
    std::thread thread_;

    FrameQueue& frame_queue_;
    algorithm::YoloDetectorRKNNV2& detector_;
    abstract_camer::IGimbal& gimbal_;
    TargetMatcher& target_matcher_;
    float cnn_threshold_;

    BYTETracker tracker_{30, 200};

    // 防跳变：记住上一帧送入 ByteTrack 的检测框，优先 IoU 匹配
    cv::Rect_<float> prev_best_box_{0, 0, 0, 0};
    bool prev_best_valid_ = false;

    SharedTrackingResult result_;
    std::mutex result_mutex_;
};

}  // namespace worker