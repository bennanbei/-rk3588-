#pragma once
#include <opencv2/opencv.hpp>
#include <rknn_api.h>
#include <string>
#include <vector>
#include <utility>
#include <chrono>
#include <memory>
#include <atomic>

namespace algorithm {

// RKNN 海天线检测器 (wasr_mobilenet_ultra_light)
// 输入: 1x384x512x3 (NHWC, uint8)
// 输出: 1x3x96x128  (3类: 0=障碍物 1=水域 2=天空)
// 输出: 海天线两点 (原图坐标)
class RKNNHorizonDetector {
public:
    RKNNHorizonDetector(const std::string& modelPath, float inferIntervalSeconds = 0.0f);
    ~RKNNHorizonDetector();

    bool detect(const cv::Mat& frame, std::pair<cv::Point, cv::Point>& horizonLine);
    bool isModelLoaded() const { return model_loaded_; }
    
    void setInferInterval(float seconds);
    bool isPredicting() const { return false; }
    
    // 获取直线参数 y = kx + b
    void getLineParams(float& k, float& b) const;

private:
    bool loadModel();
    void release();
    
    bool postprocess(const float* seg_map, int origW, int origH, std::pair<cv::Point, cv::Point>& horizonLine);
    
    // 直线拟合工具
    bool ransacFit(const std::vector<cv::Point2f>& points, float& k, float& b);
    bool ransacFilterInliersWithAngle(const std::vector<cv::Point2f>& points,
                                      std::vector<cv::Point2f>& inliers,
                                      float& k, float& b);
    bool ransacFilterInliers(const std::vector<cv::Point2f>& points,
                             std::vector<cv::Point2f>& inliers,
                             float& k, float& b);
    bool leastSquaresFit(const std::vector<cv::Point2f>& points, float& k, float& b);

private:
    std::string modelPath_;
    std::atomic<float> inferInterval_{5.0f};
    
    std::chrono::steady_clock::time_point lastInferTime_ =
        std::chrono::steady_clock::now() - std::chrono::seconds(10);
    
    bool hasCachedResult_ = false;
    std::pair<cv::Point, cv::Point> cachedLine_;
    float cachedK_ = 0.0f;
    float cachedB_ = 0.0f;
    
    // RKNN 相关
    rknn_context ctx_ = 0;
    rknn_input_output_num io_num_;
    rknn_tensor_attr* input_attrs_ = nullptr;
    rknn_tensor_attr* output_attrs_ = nullptr;
    
    // 输入输出信息
    int input_width_ = 512;   // 从模型动态读取，此为默认值
    int input_height_ = 384;
    int output_height_ = 96;   // ultra_light: 96x128
    int output_width_ = 128;
    int output_channels_ = 3;
    
    bool model_loaded_ = false;
    
    // 复用的反量化输出缓冲区，避免每次推理重新分配内存
    std::vector<float> float_output_;
};

} // namespace algorithm
