#include "seg_rknn.h"
#include <iostream>
#include <algorithm>
#include <random>
#include <cstring>
#include <cstdlib>

namespace algorithm {

RKNNHorizonDetector::RKNNHorizonDetector(const std::string& modelPath, float inferIntervalSeconds)
    : modelPath_(modelPath), inferInterval_(inferIntervalSeconds) {
    loadModel();
}

RKNNHorizonDetector::~RKNNHorizonDetector() {
    release();
}

bool RKNNHorizonDetector::loadModel() {
    // 加载 RKNN 模型
    FILE* fp = fopen(modelPath_.c_str(), "rb");
    if (!fp) {
        std::cerr << "Failed to open model file: " << modelPath_ << std::endl;
        return false;
    }
    
    fseek(fp, 0, SEEK_END);
    int model_len = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    
    void* model_data = malloc(model_len);
    if (!model_data) {
        std::cerr << "Failed to allocate memory for model" << std::endl;
        fclose(fp);
        return false;
    }
    
    if (fread(model_data, 1, model_len, fp) != model_len) {
        std::cerr << "Failed to read model file" << std::endl;
        free(model_data);
        fclose(fp);
        return false;
    }
    fclose(fp);
    
    // 初始化 RKNN 运行时
    int ret = rknn_init(&ctx_, model_data, model_len, 0, nullptr);
    free(model_data);
    
    if (ret != RKNN_SUCC) {
        std::cerr << "rknn_init failed: " << ret << std::endl;
        return false;
    }
    
    // 查询 SDK 版本
    rknn_sdk_version sdk_ver;
    ret = rknn_query(ctx_, RKNN_QUERY_SDK_VERSION, &sdk_ver, sizeof(sdk_ver));
    if (ret == RKNN_SUCC) {
        std::cout << "[seg_rknn] SDK API: " << sdk_ver.api_version 
                  << " Driver: " << sdk_ver.drv_version << std::endl;
    }
    
    // 绑定 NPU CORE_1（YOLO用CORE_0，避免争抢NPU）
    ret = rknn_set_core_mask(ctx_, RKNN_NPU_CORE_1);
    if (ret != RKNN_SUCC) {
        std::cout << "[seg_rknn] set_core_mask failed (ret=" << ret << "), using default" << std::endl;
    } else {
        std::cout << "[seg_rknn] NPU core mask: CORE_1" << std::endl;
    }
    
    // 获取输入输出信息
    ret = rknn_query(ctx_, RKNN_QUERY_IN_OUT_NUM, &io_num_, sizeof(io_num_));
    if (ret != RKNN_SUCC) {
        std::cerr << "rknn_query io_num failed: " << ret << std::endl;
        return false;
    }
    
    // 获取输入属性
    input_attrs_ = (rknn_tensor_attr*)malloc(sizeof(rknn_tensor_attr) * io_num_.n_input);
    memset(input_attrs_, 0, sizeof(rknn_tensor_attr) * io_num_.n_input);
    for (uint32_t i = 0; i < io_num_.n_input; i++) {
        input_attrs_[i].index = i;
        ret = rknn_query(ctx_, RKNN_QUERY_INPUT_ATTR, &input_attrs_[i], sizeof(rknn_tensor_attr));
        if (ret != RKNN_SUCC) {
            std::cerr << "rknn_query input attr failed: " << ret << std::endl;
            return false;
        }
    }
    
    // 获取输出属性
    output_attrs_ = (rknn_tensor_attr*)malloc(sizeof(rknn_tensor_attr) * io_num_.n_output);
    memset(output_attrs_, 0, sizeof(rknn_tensor_attr) * io_num_.n_output);
    for (uint32_t i = 0; i < io_num_.n_output; i++) {
        output_attrs_[i].index = i;
        ret = rknn_query(ctx_, RKNN_QUERY_OUTPUT_ATTR, &output_attrs_[i], sizeof(rknn_tensor_attr));
        if (ret != RKNN_SUCC) {
            std::cerr << "rknn_query output attr failed: " << ret << std::endl;
            return false;
        }
    }
    
    // 打印输入输出信息
    std::cout << "Model Input Num: " << io_num_.n_input << std::endl;
    std::cout << "Model Output Num: " << io_num_.n_output << std::endl;
    
    for (uint32_t i = 0; i < io_num_.n_input; i++) {
        std::cout << "Input[" << i << "]: " << input_attrs_[i].n_dims << " dims [";
        for (uint32_t j = 0; j < input_attrs_[i].n_dims; j++) {
            std::cout << input_attrs_[i].dims[j];
            if (j < input_attrs_[i].n_dims - 1) std::cout << ", ";
        }
        std::cout << "]" << std::endl;
    }
    
    for (uint32_t i = 0; i < io_num_.n_output; i++) {
        std::cout << "Output[" << i << "]: " << output_attrs_[i].n_dims << " dims [";
        for (uint32_t j = 0; j < output_attrs_[i].n_dims; j++) {
            std::cout << output_attrs_[i].dims[j];
            if (j < output_attrs_[i].n_dims - 1) std::cout << ", ";
        }
        std::cout << "]" << std::endl;
    }
    
    // 从输入属性获取实际输入尺寸 (NHWC: [1, H, W, 3])
    if (io_num_.n_input > 0 && input_attrs_[0].n_dims >= 4) {
        input_height_ = input_attrs_[0].dims[1];
        input_width_ = input_attrs_[0].dims[2];
        std::cout << "Input size: " << input_width_ << "x" << input_height_ << std::endl;
    }
    
    // 从输出属性获取实际输出尺寸 (NCHW: [1, C, H, W])
    if (io_num_.n_output > 0 && output_attrs_[0].n_dims >= 4) {
        output_channels_ = output_attrs_[0].dims[1];
        output_height_ = output_attrs_[0].dims[2];
        output_width_ = output_attrs_[0].dims[3];
        std::cout << "Output size: " << output_width_ << "x" << output_height_ << " channels=" << output_channels_ << std::endl;
    }
    
    // 预分配反量化输出缓冲区（一次性分配，避免每次推理重新分配内存）
    float_output_.resize(output_channels_ * output_height_ * output_width_);
    std::cout << "Preallocated float buffer: " << float_output_.size() << " elements ("
              << float_output_.size() * sizeof(float) / 1024.0 / 1024.0 << " MB)" << std::endl;
    
    model_loaded_ = true;
    return true;
}

void RKNNHorizonDetector::release() {
    if (ctx_ != 0) {
        rknn_destroy(ctx_);
        ctx_ = 0;
    }
    if (input_attrs_) {
        free(input_attrs_);
        input_attrs_ = nullptr;
    }
    if (output_attrs_) {
        free(output_attrs_);
        output_attrs_ = nullptr;
    }
    model_loaded_ = false;
}

bool RKNNHorizonDetector::detect(const cv::Mat& frame, std::pair<cv::Point, cv::Point>& horizonLine) {
    if (!model_loaded_) {
        std::cerr << "[seg_rknn] Model not loaded" << std::endl;
        return false;
    }
    
    // 推理限流
    auto now = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastInferTime_);
    if (elapsed.count() < inferInterval_.load(std::memory_order_relaxed) * 1000) {
        if (hasCachedResult_) {
            horizonLine = cachedLine_;
            return true;
        }
        return false;
    }
    
    // [seg_rknn] per-frame timing silenced for performance
    
    // 预处理
    cv::Mat resized;
    cv::resize(frame, resized, cv::Size(input_width_, input_height_));
    
    // 准备输入
    rknn_input inputs[1];
    memset(inputs, 0, sizeof(inputs));
    inputs[0].index = 0;
    inputs[0].type = RKNN_TENSOR_UINT8;
    inputs[0].size = input_width_ * input_height_ * 3;
    inputs[0].fmt = RKNN_TENSOR_NHWC;
    inputs[0].buf = resized.data;
    
    int ret = rknn_inputs_set(ctx_, io_num_.n_input, inputs);
    if (ret != RKNN_SUCC) {
        std::cerr << "[seg_rknn] rknn_inputs_set failed: " << ret << std::endl;
        return false;
    }
    
    // 执行推理
    ret = rknn_run(ctx_, nullptr);
    if (ret != RKNN_SUCC) {
        std::cerr << "[seg_rknn] rknn_run failed: " << ret << std::endl;
        return false;
    }
    
    // 查询实际 NPU 推理时间
    // NPU run_duration query silenced for performance
    
    // 查询每层性能详情（已关闭：RKNN_FLAG_COLLECT_PERF_MASK=0 避免每次推理开销）
    
    // 直接获取量化输出，检查反量化参数
    rknn_output outputs[1];
    memset(outputs, 0, sizeof(outputs));
    outputs[0].want_float = 0;  // 获取量化输出
    outputs[0].is_prealloc = 0;
    
    ret = rknn_outputs_get(ctx_, io_num_.n_output, outputs, nullptr);
    if (ret != RKNN_SUCC) {
        std::cerr << "[seg_rknn] rknn_outputs_get failed: " << ret << std::endl;
        return false;
    }
    
    const int total_elements = output_channels_ * output_height_ * output_width_;
    
    // 调试：打印反量化参数
    static bool deq_debug = false;
    if (!deq_debug) {
        std::cout << "[seg_rknn] output type=" << (int)output_attrs_[0].type 
                  << " zp=" << output_attrs_[0].zp 
                  << " scale=" << output_attrs_[0].scale
                  << " fmt=" << (int)output_attrs_[0].fmt << std::endl;
        deq_debug = true;
    }
    
    // INT8 手动反量化（RKNN 模型输出层 type=INT8，但 zero_point 使用 UINT8 语义）
    if (output_attrs_[0].type == RKNN_TENSOR_INT8) {
        int8_t* raw = (int8_t*)outputs[0].buf;
        int32_t zp = output_attrs_[0].zp;
        float scale = output_attrs_[0].scale;
        
        // 当作 UINT8 处理（reinterpret_cast），否则反量化后全为负数
        for (int i = 0; i < total_elements; i++) {
            uint8_t u = static_cast<uint8_t>(raw[i]);
            float_output_[i] = (static_cast<float>(u) - zp) * scale;
        }
    } else if (output_attrs_[0].type == RKNN_TENSOR_FLOAT16) {
        // FP16 转 float
        rknn_outputs_release(ctx_, io_num_.n_output, outputs);
        outputs[0].want_float = 1;
        ret = rknn_outputs_get(ctx_, io_num_.n_output, outputs, nullptr);
        if (ret != RKNN_SUCC) return false;
        memcpy(float_output_.data(), outputs[0].buf, total_elements * sizeof(float));
    } else {
        // 其他类型直接拷贝
        memcpy(float_output_.data(), outputs[0].buf, total_elements * sizeof(float));
    }
    
    // 后处理
    bool success = postprocess(float_output_.data(), frame.cols, frame.rows, horizonLine);
    
    // 释放输出
    rknn_outputs_release(ctx_, io_num_.n_output, outputs);
    
    if (success) {
        cachedLine_ = horizonLine;
        hasCachedResult_ = true;
        lastInferTime_ = now;
        // horizon print silenced for performance
    }
    
    return success;
}

bool RKNNHorizonDetector::postprocess(const float* seg_map, int origW, int origH, std::pair<cv::Point, cv::Point>& horizonLine) {
    if (seg_map == nullptr) {
        return false;
    }
    
    // 找到水域和天空的边界点
    std::vector<cv::Point2f> horizon_points;
    
    int sky_water_transitions = 0;
    int total_points = 0;
    int hw = output_height_ * output_width_;
    
    // 精确诊断：打印特定行/列的值
    static bool diag_done = false;
    if (!diag_done) {
        std::cerr << "[seg_rknn] DIAG: output dims=" << output_height_ << "x" << output_width_ << " hw=" << hw << std::endl;
        // 打印 x=64 列 y=15~20 的每个值
        for (int y = 14; y <= 22; y++) {
            int idx = 0 * hw + y * output_width_ + 64;
            float c0 = seg_map[idx];
            float c1 = seg_map[1 * hw + y * output_width_ + 64];
            float c2 = seg_map[2 * hw + y * output_width_ + 64];
            // 二分类：水域(1) vs 非水域(0)
            int cls = (c1 >= c0 && c1 >= c2) ? 1 : 0;
            std::cerr << "  y=" << y << " obs=" << c0 << " water=" << c1 << " sky=" << c2 << " -> class=" << cls << " (1=water, 0=non-water)" << std::endl;
        }
        diag_done = true;
    }
    
    for (int x = 0; x < output_width_; x++) {
        // 从下到上扫描：从底部开始寻找水域->非水域的过渡
        for (int y = output_height_ - 2; y >= 1; y--) {
            total_points++;
            auto class_at = [&](int yy, int xx) {
                const float c0 = seg_map[0 * hw + yy * output_width_ + xx];
                const float c1 = seg_map[1 * hw + yy * output_width_ + xx];
                const float c2 = seg_map[2 * hw + yy * output_width_ + xx];
                // 合并天空(2)和障碍物(0)为非水域(0)，只保留水域(1)
                if (c1 >= c0 && c1 >= c2) return 1;  // 水域
                return 0;  // 非水域（天空或障碍物）
            };

            int current_class = class_at(y, x);
            int above_class = class_at(y - 1, x);
            
            // 水域(1) -> 非水域(0) 的过渡
            bool is_transition = false;
            if (current_class == 1 && above_class == 0) {
                is_transition = true;
            }
            
            if (is_transition) {
                sky_water_transitions++;
                float orig_x = x * origW / output_width_;
                float orig_y = y * origH / output_height_;
                horizon_points.emplace_back(orig_x, orig_y);
                break;
            }
        }
    }
    
    // postprocess stats silenced for performance
    
    // 过滤掉极端点：只保留中间60%区域的点
    std::vector<cv::Point2f> filtered_points;
    const float y_min = origH * 0.2f;  // 顶部20%
    const float y_max = origH * 0.8f;  // 底部80%
    for (const auto& p : horizon_points) {
        if (p.y >= y_min && p.y <= y_max) {
            filtered_points.push_back(p);
        }
    }
    // filtered stats silenced for performance
    
    if (filtered_points.size() < 10) {
        return false;
    }
    
    // 使用 RANSAC 拟合直线
    float k, b;
    if (ransacFit(filtered_points, k, b)) {
        // 计算直线在图像边界上的点
        cv::Point pt1(0, b);
        cv::Point pt2(origW, k * origW + b);
        
        horizonLine = std::make_pair(pt1, pt2);
        cachedK_ = k;
        cachedB_ = b;
        return true;
    }

    return false;
}

bool RKNNHorizonDetector::ransacFit(const std::vector<cv::Point2f>& points, float& k, float& b) {
    if (points.size() < 2) return false;
    
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, points.size() - 1);
    
    const int iterations = 100;
    const float threshold = 50.0f;  // 增加阈值以适应大尺寸图像
    int max_inliers = 0;
    float best_k = 0, best_b = 0;
    
    for (int i = 0; i < iterations; i++) {
        // 随机选择两个点
        int idx1 = dis(gen);
        int idx2 = dis(gen);
        while (idx2 == idx1) {
            idx2 = dis(gen);
        }
        
        const cv::Point2f& p1 = points[idx1];
        const cv::Point2f& p2 = points[idx2];
        
        if (std::abs(p1.x - p2.x) < 1e-6) continue; // 避免垂直线
        
        // 计算直线参数 y = kx + b
        float k_curr = (p2.y - p1.y) / (p2.x - p1.x);
        float b_curr = p1.y - k_curr * p1.x;
        
        // 计算内点
        int inliers = 0;
        for (const auto& p : points) {
            float y_pred = k_curr * p.x + b_curr;
            if (std::abs(p.y - y_pred) < threshold) {
                inliers++;
            }
        }
        
        if (inliers > max_inliers) {
            max_inliers = inliers;
            best_k = k_curr;
            best_b = b_curr;
        }
    }
    
    if (max_inliers > points.size() * 0.3) { // 至少30%的点支持
        k = best_k;
        b = best_b;
        return true;
    }
    
    return false;
}

void RKNNHorizonDetector::setInferInterval(float seconds) {
    inferInterval_.store(seconds, std::memory_order_relaxed);
}

void RKNNHorizonDetector::getLineParams(float& k, float& b) const {
    k = cachedK_;
    b = cachedB_;
}

} // namespace algorithm
