
 #pragma once
 #include <functional>

namespace cv{
    class Mat;
}

 
 namespace abstract_camer {
    
 class IVideoStream {

 public:
    using FrameCallback=std::function<void(const cv::Mat&)>;
    
    virtual ~IVideoStream() = default;
    virtual bool start()=0;
    virtual void stop() = 0;
    virtual bool is_running() const = 0;

    virtual void set_on_frame(FrameCallback cb)=0;
    
 };
 } // namespace abstract_camer

