#include "FeatureExtractor.h"

#include <fstream>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <chrono>

FeatureExtractor::FeatureExtractor() {}

FeatureExtractor::~FeatureExtractor() {
    release();
}

void FeatureExtractor::release() {
    if (ctx_ != 0) {
        rknn_destroy(ctx_);
        ctx_ = 0;
    }
    if (inputAttrs_) {
        free(inputAttrs_);
        inputAttrs_ = nullptr;
    }
    if (outputAttrs_) {
        free(outputAttrs_);
        outputAttrs_ = nullptr;
    }
    modelLoaded_ = false;
}

bool FeatureExtractor::loadEngine(const std::string& modelPath) {
    release();

    // 1. 读入模型文件
    FILE* fp = fopen(modelPath.c_str(), "rb");
    if (!fp) {
        std::cerr << "[ReID] 无法打开模型: " << modelPath << std::endl;
        return false;
    }
    fseek(fp, 0, SEEK_END);
    int modelLen = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    void* modelData = malloc(modelLen);
    if (!modelData) {
        std::cerr << "[ReID] malloc 失败" << std::endl;
        fclose(fp);
        return false;
    }
    if (fread(modelData, 1, modelLen, fp) != (size_t)modelLen) {
        std::cerr << "[ReID] 读取模型失败" << std::endl;
        free(modelData);
        fclose(fp);
        return false;
    }
    fclose(fp);

    // 2. 初始化 RKNN
    int ret = rknn_init(&ctx_, modelData, modelLen, 0, nullptr);
    free(modelData);
    if (ret != RKNN_SUCC) {
        std::cerr << "[ReID] rknn_init 失败: " << ret << std::endl;
        return false;
    }

    // 3. 绑定 NPU CORE_2（YOLO=CORE_0, seg=CORE_1，避免争抢）
    ret = rknn_set_core_mask(ctx_, RKNN_NPU_CORE_2);
    if (ret != RKNN_SUCC) {
        std::cerr << "[ReID] set_core_mask CORE_2 失败 (ret=" << ret << "), 使用默认 core" << std::endl;
    } else {
        std::cout << "[ReID] NPU core mask: CORE_2" << std::endl;
    }

    // 4. 查询输入输出信息
    ret = rknn_query(ctx_, RKNN_QUERY_IN_OUT_NUM, &ioNum_, sizeof(ioNum_));
    if (ret != RKNN_SUCC) {
        std::cerr << "[ReID] rknn_query io_num 失败: " << ret << std::endl;
        release();
        return false;
    }

    inputAttrs_ = (rknn_tensor_attr*)malloc(sizeof(rknn_tensor_attr) * ioNum_.n_input);
    memset(inputAttrs_, 0, sizeof(rknn_tensor_attr) * ioNum_.n_input);
    for (uint32_t i = 0; i < ioNum_.n_input; i++) {
        inputAttrs_[i].index = i;
        ret = rknn_query(ctx_, RKNN_QUERY_INPUT_ATTR, &inputAttrs_[i], sizeof(rknn_tensor_attr));
        if (ret != RKNN_SUCC) {
            std::cerr << "[ReID] rknn_query input attr 失败: " << ret << std::endl;
            release();
            return false;
        }
    }

    outputAttrs_ = (rknn_tensor_attr*)malloc(sizeof(rknn_tensor_attr) * ioNum_.n_output);
    memset(outputAttrs_, 0, sizeof(rknn_tensor_attr) * ioNum_.n_output);
    for (uint32_t i = 0; i < ioNum_.n_output; i++) {
        outputAttrs_[i].index = i;
        ret = rknn_query(ctx_, RKNN_QUERY_OUTPUT_ATTR, &outputAttrs_[i], sizeof(rknn_tensor_attr));
        if (ret != RKNN_SUCC) {
            std::cerr << "[ReID] rknn_query output attr 失败: " << ret << std::endl;
            release();
            return false;
        }
    }

    // 打印信息
    std::cout << "[ReID] 模型加载成功" << std::endl;
    std::cout << "[ReID]   输入: " << ioNum_.n_input << " 个, 输出: " << ioNum_.n_output << " 个" << std::endl;
    for (uint32_t i = 0; i < ioNum_.n_input; i++) {
        std::cout << "[ReID]   输入[" << i << "]: fmt=" << inputAttrs_[i].fmt
                  << " dtype=" << inputAttrs_[i].type
                  << " dims=[";
        for (uint32_t j = 0; j < inputAttrs_[i].n_dims; j++) {
            if (j > 0) std::cout << ",";
            std::cout << inputAttrs_[i].dims[j];
        }
        std::cout << "]" << std::endl;
    }
    for (uint32_t i = 0; i < ioNum_.n_output; i++) {
        std::cout << "[ReID]   输出[" << i << "]: fmt=" << outputAttrs_[i].fmt
                  << " dtype=" << outputAttrs_[i].type
                  << " dims=[";
        for (uint32_t j = 0; j < outputAttrs_[i].n_dims; j++) {
            if (j > 0) std::cout << ",";
            std::cout << outputAttrs_[i].dims[j];
        }
        std::cout << "]" << std::endl;
    }

    modelLoaded_ = true;
    return true;
}

cv::Mat FeatureExtractor::preprocess(const cv::Mat& roi) {
    // Resize
    cv::Mat resized;
    cv::resize(roi, resized, cv::Size(inputWidth_, inputHeight_));

    // BGR → RGB + 归一化 → NHWC float32
    cv::Mat nchw(inputHeight_, inputWidth_, CV_32FC3);
    float* data = (float*)nchw.data;

    for (int y = 0; y < inputHeight_; y++) {
        for (int x = 0; x < inputWidth_; x++) {
            const cv::Vec3b& pixel = resized.at<cv::Vec3b>(y, x);

            // BGR → RGB + /255 + normalize
            float r = (pixel[2] / 255.0f - mean_[0]) / std_[0];
            float g = (pixel[1] / 255.0f - mean_[1]) / std_[1];
            float b = (pixel[0] / 255.0f - mean_[2]) / std_[2];

            // NHWC layout: HWC order
            int idx = (y * inputWidth_ + x) * 3;
            data[idx + 0] = r;
            data[idx + 1] = g;
            data[idx + 2] = b;
        }
    }

    return nchw;
}

cv::Mat FeatureExtractor::extract(const cv::Mat& roi) {
    if (!modelLoaded_ || roi.empty()) {
        return cv::Mat();
    }

    static int extract_cnt = 0;
    extract_cnt++;
    auto t0 = std::chrono::high_resolution_clock::now();

    // 预处理
    cv::Mat processed = preprocess(roi);
    auto t1 = std::chrono::high_resolution_clock::now();

    // 设置输入
    rknn_input inputs[1];
    memset(inputs, 0, sizeof(inputs));
    inputs[0].index = 0;
    inputs[0].type = RKNN_TENSOR_FLOAT32;
    inputs[0].size = processed.total() * processed.elemSize();
    inputs[0].buf = processed.data;
    inputs[0].fmt = RKNN_TENSOR_NHWC;
    inputs[0].pass_through = 0;

    int ret = rknn_inputs_set(ctx_, 1, inputs);
    if (ret < 0) {
        std::cerr << "[ReID] rknn_inputs_set 失败: " << ret << std::endl;
        return cv::Mat();
    }

    // 推理
    ret = rknn_run(ctx_, nullptr);
    auto t2 = std::chrono::high_resolution_clock::now();
    if (ret < 0) {
        std::cerr << "[ReID] rknn_run 失败: " << ret << std::endl;
        return cv::Mat();
    }

    // 获取输出
    rknn_output outputs[1];
    memset(outputs, 0, sizeof(outputs));
    outputs[0].want_float = 1;
    outputs[0].is_prealloc = 0;

    ret = rknn_outputs_get(ctx_, 1, outputs, nullptr);
    auto t3 = std::chrono::high_resolution_clock::now();
    if (ret < 0) {
        std::cerr << "[ReID] rknn_outputs_get 失败: " << ret << std::endl;
        return cv::Mat();
    }

    // 转为 cv::Mat 并做 L2 归一化
    float* outData = (float*)outputs[0].buf;
    int outSize = outputs[0].size / sizeof(float);

    cv::Mat feature(1, outSize, CV_32F);
    std::memcpy(feature.ptr<float>(), outData, outSize * sizeof(float));

    // L2 归一化
    double norm = cv::norm(feature, cv::NORM_L2);
    if (norm > 1e-8) {
        feature /= norm;
    }

    // 释放输出
    rknn_outputs_release(ctx_, 1, outputs);

    auto pre_ms = std::chrono::duration_cast<std::chrono::milliseconds>(t1 - t0).count();
    auto run_ms = std::chrono::duration_cast<std::chrono::milliseconds>(t2 - t1).count();
    auto get_ms = std::chrono::duration_cast<std::chrono::milliseconds>(t3 - t2).count();
    if (extract_cnt % 30 == 1) {
        std::cout << "[ReID#" << extract_cnt << "] pre=" << pre_ms << "ms rknn_run=" << run_ms << "ms output=" << get_ms << "ms" << std::endl;
    }

    return feature;
}

std::vector<cv::Mat> FeatureExtractor::extractBatch(const std::vector<cv::Mat>& rois) {
    std::vector<cv::Mat> features;
    features.reserve(rois.size());
    for (const auto& roi : rois) {
        features.push_back(extract(roi));
    }
    return features;
}

float FeatureExtractor::cosineSimilarity(const cv::Mat& feat1, const cv::Mat& feat2) {
    if (feat1.empty() || feat2.empty()) {
        return 0.0f;
    }
    // 两个 L2 归一化向量的点积就是余弦相似度
    return static_cast<float>(feat1.dot(feat2));
}
