#include "TargetMatcher.h"
#include <iostream>

TargetMatcher::TargetMatcher(float threshold)
    : threshold_(threshold) {
    featureExtractor_ = std::make_shared<FeatureExtractor>();
}

bool TargetMatcher::loadFeatureExtractor(const std::string& enginePath) {
    if (!featureExtractor_) {
        featureExtractor_ = std::make_shared<FeatureExtractor>();
    }
    return featureExtractor_->loadEngine(enginePath);
}

bool TargetMatcher::setTargetTemplate(const cv::Mat& frame, const cv::Rect& roi) {
    if (roi.x < 0 || roi.y < 0 || 
        roi.x + roi.width > frame.cols || 
        roi.y + roi.height > frame.rows) {
        return false;
    }
    
    cv::Mat templateImg = frame(roi).clone();
    return addTemplate(templateImg);
}

bool TargetMatcher::setMultipleTemplates(const std::vector<std::string>& templatePaths) {
    templateFeatures_.clear();
    templateImages_.clear();
    
    for (const auto& path : templatePaths) {
        cv::Mat templateImg = cv::imread(path);
        if (templateImg.empty()) {
            std::cerr << "[错误] 无法加载模板: " << path << std::endl;
            continue;
        }
        
        if (!addTemplate(templateImg)) {
            std::cerr << "[错误] 添加模板失败: " << path << std::endl;
        } else {
            std::cout << "[模板] 已添加: " << path << std::endl;
        }
    }
    
    if (templateFeatures_.empty()) {
        std::cerr << "[错误] 没有成功加载任何模板" << std::endl;
        return false;
    }
    
    std::cout << "[TargetMatcher] 成功加载 " << templateFeatures_.size() << " 个模板到特征数据库" << std::endl;
    return true;
}

bool TargetMatcher::addTemplate(const cv::Mat& templateImg) {
    if (templateImg.empty()) {
        return false;
    }
    
    if (!featureExtractor_ || !featureExtractor_->isLoaded()) {
        std::cerr << "[错误] CNN特征提取器未加载" << std::endl;
        return false;
    }
    
    // 提取CNN特征（128维）
    cv::Mat feature = featureExtractor_->extract(templateImg);
    if (feature.empty()) {
        std::cerr << "[错误] 特征提取失败" << std::endl;
        return false;
    }
    
    // 添加到特征数据库
    templateFeatures_.push_back(feature.clone());
    templateImages_.push_back(templateImg.clone());
    
    int idx = templateFeatures_.size() - 1;
    std::cout << "[模板#" << idx << "] 尺寸: " << templateImg.cols << "x" << templateImg.rows
              << ", CNN特征: " << feature.cols << "维" << std::endl;
    
    return true;
}

MatchScore TargetMatcher::findTarget(const cv::Mat& frame, const std::vector<algorithm::YoloDetectorRKNNV2::Detection>& detections) {
    if (!isReady() || detections.empty()) {
        return MatchScore();
    }
    
    MatchScore best;
    
    static int debugCount = 0;
    bool showDebug = (++debugCount % 30 == 1);  // 每30帧打印一次
    
    // 遍历所有检测框
    for (size_t i = 0; i < detections.size(); ++i) {
        const auto& det = detections[i];
        
        // 边界检查
        if (det.box.x < 0 || det.box.y < 0 || 
            det.box.x + det.box.width > frame.cols || 
            det.box.y + det.box.height > frame.rows) {
            continue;
        }
        
        cv::Mat roi = frame(det.box);
        
        // YoloDetector::Detection uses 'confidence' not 'conf'
        // This function is not used in the current implementation
        
        // 提取当前检测框的CNN特征
        cv::Mat queryFeature = featureExtractor_->extract(roi);
        if (queryFeature.empty()) {
            continue;
        }
        
        // 与模板数据库中的所有特征比较（多模板模式）
        // 所有模板属于同一个目标，取最高相似度
        float bestSimilarity = 0.0f;
        
        for (int t = 0; t < static_cast<int>(templateFeatures_.size()); ++t) {
            float similarity = FeatureExtractor::cosineSimilarity(queryFeature, templateFeatures_[t]);
            
            if (similarity > bestSimilarity) {
                bestSimilarity = similarity;
                // ✅ 不切换模板索引，所有模板属于同一目标
            }
        }
        
        // 更新最佳匹配（固定目标ID）
        if (bestSimilarity > best.combinedScore) {
            best.index = i;
            best.bestTemplateIndex = 0;  // ✅ 固定为0，表示同一个目标
            best.similarity = bestSimilarity;
            best.combinedScore = bestSimilarity;
            
            if (showDebug) {
                std::cout << "  [检测#" << i << "] 目标相似度=" << bestSimilarity 
                          << " | 模板数=" << templateFeatures_.size() << std::endl;
            }
        }
    }
    
    // 阈值过滤
    if (best.combinedScore < threshold_) {
        if (showDebug && best.combinedScore > 0) {
            std::cout << "  [过滤] 最佳相似度 " << best.combinedScore 
                      << " < 阈值 " << threshold_ << std::endl;
        }
        return MatchScore();
    }
    
    return best;
}

float TargetMatcher::computeSimilarity(const cv::Mat& roi) {
    if (!isReady() || roi.empty()) {
        return 0.0f;
    }
    
    // 提取ROI的CNN特征
    cv::Mat queryFeature = featureExtractor_->extract(roi);
    if (queryFeature.empty()) {
        return 0.0f;
    }
    
    // 与模板数据库中的所有特征比较，取最高相似度
    float bestSimilarity = 0.0f;
    for (const auto& templateFeature : templateFeatures_) {
        float similarity = FeatureExtractor::cosineSimilarity(queryFeature, templateFeature);
        if (similarity > bestSimilarity) {
            bestSimilarity = similarity;
        }
    }
    
    return bestSimilarity;
}

cv::Mat TargetMatcher::extractFeature(const cv::Mat& roi) {
    if (!featureExtractor_ || !featureExtractor_->isLoaded()) {
        return cv::Mat();
    }
    
    if (roi.empty()) {
        return cv::Mat();
    }
    
    return featureExtractor_->extract(roi);
}
