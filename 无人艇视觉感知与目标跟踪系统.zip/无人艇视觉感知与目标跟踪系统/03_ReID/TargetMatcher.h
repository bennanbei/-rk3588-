#ifndef TARGET_MATCHER_H
#define TARGET_MATCHER_H

#include <opencv2/opencv.hpp>
#include <vector>
#include <memory>
#include "FeatureExtractor.h"
#include "../detection/yolo_detect_rknn_v2.h"

struct MatchScore {
    int index;                  // 匹配的检测框索引
    int bestTemplateIndex;      // 最佳匹配的模板索引
    float similarity;           // CNN特征相似度
    float combinedScore;        // 综合得分（这里等于similarity）
    
    MatchScore() : index(-1), bestTemplateIndex(-1), similarity(0), combinedScore(0) {}
    
    bool isValid() const { return index >= 0 && combinedScore > 0; }
};

/**
 * 目标匹配器（借鉴人脸识别思路）
 * 使用CNN特征提取 + 余弦相似度匹配
 */
class TargetMatcher {
public:
    TargetMatcher(float threshold = 0.5f);
    
    // 加载CNN特征提取器
    bool loadFeatureExtractor(const std::string& enginePath);
    
    // 设置单个模板
    bool setTargetTemplate(const cv::Mat& frame, const cv::Rect& roi);
    
    // 设置多个模板（从文件路径列表）
    bool setMultipleTemplates(const std::vector<std::string>& templatePaths);
    
    // 在检测结果中查找目标（数据库查询模式）
    MatchScore findTarget(const cv::Mat& frame, const std::vector<algorithm::YoloDetectorRKNNV2::Detection>& detections);
    
    void setThreshold(float thresh) { threshold_ = thresh; }
    
    bool hasTemplate() const { return !templateFeatures_.empty(); }
    
    int getTemplateCount() const { return templateFeatures_.size(); }
    
    bool isReady() const { return featureExtractor_ && featureExtractor_->isLoaded() && hasTemplate(); }
    
    // 计算单个ROI与模板库的最高相似度
    float computeSimilarity(const cv::Mat& roi);
    
    // 提取单个ROI的特征向量（用于ByteTrack）
    cv::Mat extractFeature(const cv::Mat& roi);

private:
    // 添加模板到数据库
    bool addTemplate(const cv::Mat& templateImg);
    
    // CNN特征提取器
    std::shared_ptr<FeatureExtractor> featureExtractor_;
    
    // 模板特征数据库（类似人脸数据库）
    std::vector<cv::Mat> templateFeatures_;    // 每个模板的128维特征向量
    std::vector<cv::Mat> templateImages_;      // 原始模板图像（用于调试）
    
    float threshold_;
};

#endif
