#ifndef FEATURE_EXTRACTOR_H
#define FEATURE_EXTRACTOR_H

#include <opencv2/opencv.hpp>
#include <rknn_api.h>
#include <vector>
#include <string>
#include <memory>

/**
 * CNN特征提取器（基于 RKNN / TensorRT 加速）
 * 使用 OSNet x0.5 ReID 模型，将 ROI 转换为 512 维特征向量
 *
 * - RK3588: 使用 RKNN runtime（rknn_init / rknn_run）
 * - NVIDIA GPU: 可选使用 TensorRT（定义 USE_TENSORRT）
 */
class FeatureExtractor {
public:
    FeatureExtractor();
    ~FeatureExtractor();
    
    // 加载 RKNN 模型
    bool loadEngine(const std::string& modelPath);
    
    // 提取单个ROI的特征向量（512维，已 L2 归一化）
    cv::Mat extract(const cv::Mat& roi);
    
    // 批量提取特征
    std::vector<cv::Mat> extractBatch(const std::vector<cv::Mat>& rois);
    
    // 计算两个特征向量的余弦相似度
    static float cosineSimilarity(const cv::Mat& feat1, const cv::Mat& feat2);
    
    // 检查是否已加载
    bool isLoaded() const { return modelLoaded_; }

    // 获取特征维度
    int getFeatureDim() const { return featureDim_; }

private:
    // 预处理ROI: resize→BGR2RGB→归一化→NHWC float32
    cv::Mat preprocess(const cv::Mat& roi);
    
    // 释放资源
    void release();
    
    // RKNN 资源
    rknn_context ctx_ = 0;
    rknn_input_output_num ioNum_;
    rknn_tensor_attr* inputAttrs_ = nullptr;
    rknn_tensor_attr* outputAttrs_ = nullptr;
    
    // 模型参数
    int inputWidth_ = 128;
    int inputHeight_ = 256;
    int featureDim_ = 512;
    bool modelLoaded_ = false;
    
    // ImageNet 归一化参数
    const float mean_[3] = {0.485f, 0.456f, 0.406f};
    const float std_[3]  = {0.229f, 0.224f, 0.225f};
};

#endif // FEATURE_EXTRACTOR_H
