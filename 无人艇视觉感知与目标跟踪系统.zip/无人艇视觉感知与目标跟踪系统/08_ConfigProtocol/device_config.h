#ifndef DEVICE_CONFIG_H
#define DEVICE_CONFIG_H

#include <string>
#include <cstdint>

enum class DeviceType : uint8_t {
    Ruichuan,
    Haikang,
};

struct DeviceConfig {
    std::string device_id;   // 建议加：唯一ID
    DeviceType device_type;
    std::string ip;
    uint16_t port;
    uint16_t local_port;
    std::string rtsp_url;
    
    
};

// 只声明，不定义（避免多重定义）
extern const DeviceConfig ruichuan_config;
extern const DeviceConfig haikang_config;

#endif
