#include "device_config.h"

const DeviceConfig ruichuan_config{
    "dev_01",
    DeviceType::Ruichuan,
    "192.168.144.25",
    37260,
    37260,  // 本地接收端口
    "rtsp://192.168.144.25:8554/video1",
  
};

const DeviceConfig haikang_config{
    "dev_02",
    DeviceType::Haikang,
    "192.168.1.160",
    10000,
    0,
    "rtsp://192.168.1.160:10000/video1",
   
};