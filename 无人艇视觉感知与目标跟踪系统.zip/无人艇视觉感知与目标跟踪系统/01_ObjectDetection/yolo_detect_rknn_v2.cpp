#include "yolo_detect_rknn_v2.h"
#include <iostream>
#include <algorithm>
#include <numeric>
#include <cstring>
#include <cstdlib>
#include <array>

namespace algorithm {

YoloDetectorRKNNV2::YoloDetectorRKNNV2(const Config& cfg) : config_(cfg) {
    input_width_ = cfg.input_width;
    input_height_ = cfg.input_height;
}

YoloDetectorRKNNV2::~YoloDetectorRKNNV2() {
    release();
}

bool YoloDetectorRKNNV2::load_model(const std::string& model_path) {
    model_path_ = model_path;
    
    // 加载 RKNN 模型
    FILE* fp = fopen(model_path.c_str(), "rb");
    if (!fp) {
        std::cerr << "Failed to open model file: " << model_path << std::endl;
        return false;
    }
    
    fseek(fp, 0, SEEK_END);
    int model_len = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    
    void* model_data = malloc(model_len);
    if (!model_data) {
        std::cerr << "Failed to allocate memory for model" << std::endl;
        fclose(fp);
        return false;
    }
    
    if (fread(model_data, 1, model_len, fp) != model_len) {
        std::cerr << "Failed to read model file" << std::endl;
        free(model_data);
        fclose(fp);
        return false;
    }
    fclose(fp);
    
    // 初始化 RKNN 运行时
    int ret = rknn_init(&ctx_, model_data, model_len, 0, nullptr);
    free(model_data);
    
    if (ret != RKNN_SUCC) {
        std::cerr << "rknn_init failed: " << ret << std::endl;
        return false;
    }

    // 绑定 NPU CORE_0（与 Seg 的 CORE_1_2 并行，互不干扰）
    ret = rknn_set_core_mask(ctx_, RKNN_NPU_CORE_0);
    if (ret != RKNN_SUCC) {
        std::cerr << "[yolo] set_core_mask CORE_0 failed (ret=" << ret << "), using default" << std::endl;
    } else {
        std::cout << "[yolo] NPU core mask: CORE_0" << std::endl;
    }
    
    // 获取输入输出信息
    ret = rknn_query(ctx_, RKNN_QUERY_IN_OUT_NUM, &io_num_, sizeof(io_num_));
    if (ret != RKNN_SUCC) {
        std::cerr << "rknn_query io_num failed: " << ret << std::endl;
        return false;
    }
    
    // 获取输入属性
    input_attrs_ = (rknn_tensor_attr*)malloc(sizeof(rknn_tensor_attr) * io_num_.n_input);
    memset(input_attrs_, 0, sizeof(rknn_tensor_attr) * io_num_.n_input);
    for (uint32_t i = 0; i < io_num_.n_input; i++) {
        input_attrs_[i].index = i;
        ret = rknn_query(ctx_, RKNN_QUERY_INPUT_ATTR, &input_attrs_[i], sizeof(rknn_tensor_attr));
        if (ret != RKNN_SUCC) {
            std::cerr << "rknn_query input attr failed: " << ret << std::endl;
            return false;
        }
    }
    
    // 获取输出属性
    output_attrs_ = (rknn_tensor_attr*)malloc(sizeof(rknn_tensor_attr) * io_num_.n_output);
    memset(output_attrs_, 0, sizeof(rknn_tensor_attr) * io_num_.n_output);
    for (uint32_t i = 0; i < io_num_.n_output; i++) {
        output_attrs_[i].index = i;
        ret = rknn_query(ctx_, RKNN_QUERY_OUTPUT_ATTR, &output_attrs_[i], sizeof(rknn_tensor_attr));
        if (ret != RKNN_SUCC) {
            std::cerr << "rknn_query output attr failed: " << ret << std::endl;
            return false;
        }
    }
    
    num_outputs_ = io_num_.n_output;
    
    // 检测输出格式
    if (num_outputs_ == 1 && output_attrs_[0].n_dims >= 3) {
        is_multibranch_output_ = false;

        // 兼容两种常见布局：NCHW(1,84,8400) 或 NHWC(1,8400,84)
        int d1 = output_attrs_[0].dims[1];
        int d2 = output_attrs_[0].dims[2];
        if (d1 == 84) {
            output_is_nhwc_ = false;
            output_num_features_ = d1;
            output_num_proposals_ = d2;
        } else if (d2 == 84) {
            output_is_nhwc_ = true;
            output_num_proposals_ = d1;
            output_num_features_ = d2;
        } else {
            // 非COCO自定义模型：NCHW(1,feat,prop) 中 feat << prop，d1小=feat
            //                 NHWC(1,prop,feat) 中 prop >> feat，d1大=prop
            int feat_dim = std::min(d1, d2);   // features/通道数（小的一维）
            int prop_dim = std::max(d1, d2);   // proposals（大的一维）
            output_is_nhwc_ = (d1 > d2);       // d1大→NHWC, d1小→NCHW
            output_num_features_ = feat_dim;
            output_num_proposals_ = prop_dim;
        }

        std::cout << "Detected YOLOv8 output format: "
                  << (output_is_nhwc_ ? "NHWC" : "NCHW")
                  << " proposals=" << output_num_proposals_
                  << " features=" << output_num_features_
                  << std::endl;
    } else if (num_outputs_ == 9) {
        is_multibranch_output_ = true;
        std::cout << "Detected multi-branch output format (9 outputs)" << std::endl;
    } else {
        std::cout << "Unknown output format, trying standard YOLOv8" << std::endl;
        is_multibranch_output_ = false;
    }
    
    // 打印模型信息
    std::cout << "Model loaded successfully:" << std::endl;
    std::cout << "  Input: " << io_num_.n_input << " inputs" << std::endl;
    std::cout << "  Output: " << io_num_.n_output << " outputs" << std::endl;
    std::cout << "  Format: " << (is_multibranch_output_ ? "Multi-branch" : "YOLOv8 standard") << std::endl;
    
    // 打印输出维度详情
    for (uint32_t i = 0; i < io_num_.n_output; i++) {
        std::cout << "  Output[" << i << "] dims: ";
        for (uint32_t j = 0; j < output_attrs_[i].n_dims; j++) {
            std::cout << output_attrs_[i].dims[j];
            if (j < output_attrs_[i].n_dims - 1) std::cout << "x";
        }
        std::cout << std::endl;
    }
    
    model_loaded_ = true;
    return true;
}

void YoloDetectorRKNNV2::release() {
    if (ctx_ != 0) {
        rknn_destroy(ctx_);
        ctx_ = 0;
    }
    if (input_attrs_) {
        free(input_attrs_);
        input_attrs_ = nullptr;
    }
    if (output_attrs_) {
        free(output_attrs_);
        output_attrs_ = nullptr;
    }
    model_loaded_ = false;
}

cv::Mat YoloDetectorRKNNV2::preprocess(const cv::Mat& frame) {
    cv::Mat processed;
    
    if (config_.enable_letterbox) {
        // Letterbox 缩放
        float scale = std::min(static_cast<float>(input_width_) / frame.cols,
                              static_cast<float>(input_height_) / frame.rows);
        
        int new_width = static_cast<int>(frame.cols * scale);
        int new_height = static_cast<int>(frame.rows * scale);
        
        cv::resize(frame, processed, cv::Size(new_width, new_height));
        
        // 计算填充
        pad_x_ = (input_width_ - new_width) / 2.0f;
        pad_y_ = (input_height_ - new_height) / 2.0f;
        
        // 创建填充后的图像
        cv::Mat padded(input_height_, input_width_, CV_8UC3, cv::Scalar(114, 114, 114));
        processed.copyTo(padded(cv::Rect(pad_x_, pad_y_, new_width, new_height)));
        processed = padded;
    } else {
        // 直接缩放
        cv::resize(frame, processed, cv::Size(input_width_, input_height_));
        pad_x_ = 0;
        pad_y_ = 0;
    }
    
    return processed;
}

std::vector<YoloDetectorRKNNV2::Detection> YoloDetectorRKNNV2::detect(const cv::Mat& frame) {
    if (!model_loaded_) {
        std::cerr << "Model not loaded" << std::endl;
        return {};
    }
    
    // 预处理
    cv::Mat input_img = preprocess(frame);
    
    // BGR → RGB 转换（YOLO模型在RGB图像上训练）
    cv::cvtColor(input_img, input_img, cv::COLOR_BGR2RGB);
    
    // 准备输入
    rknn_input inputs[1];
    memset(inputs, 0, sizeof(inputs));
    inputs[0].index = 0;
    inputs[0].type = RKNN_TENSOR_UINT8;
    inputs[0].size = input_width_ * input_height_ * 3;
    inputs[0].fmt = RKNN_TENSOR_NHWC;
    inputs[0].buf = input_img.data;
    
    int ret = rknn_inputs_set(ctx_, io_num_.n_input, inputs);
    if (ret != RKNN_SUCC) {
        std::cerr << "rknn_inputs_set failed: " << ret << std::endl;
        return {};
    }
    
    // 执行推理
    ret = rknn_run(ctx_, nullptr);
    if (ret != RKNN_SUCC) {
        std::cerr << "rknn_run failed: " << ret << std::endl;
        return {};
    }
    
    // 获取输出
    rknn_output outputs[9];  // 最多支持9个输出
    memset(outputs, 0, sizeof(outputs));
    for (int i = 0; i < num_outputs_; i++) {
        outputs[i].want_float = 1;
    }
    
    ret = rknn_outputs_get(ctx_, num_outputs_, outputs, nullptr);
    if (ret != RKNN_SUCC) {
        std::cerr << "rknn_outputs_get failed: " << ret << std::endl;
        return {};
    }
    
    // 后处理
    std::vector<Detection> detections;
    
    if (is_multibranch_output_) {
        // 多分支输出格式
        std::vector<const float*> output_ptrs;
        for (int i = 0; i < num_outputs_; i++) {
            output_ptrs.push_back((const float*)outputs[i].buf);
        }
        detections = postprocess_multibranch(output_ptrs.data(), num_outputs_, frame.cols, frame.rows);
    } else {
        // YOLOv8 标准输出格式
        const float* output_data = (const float*)outputs[0].buf;
        detections = postprocess_yolov8(output_data, frame.cols, frame.rows);
    }
    
    // 释放输出
    rknn_outputs_release(ctx_, num_outputs_, outputs);
    
    // 调试：每30帧打印一次检测结果（减少I/O卡顿）
    static int detect_cnt = 0;
    detect_cnt++;
    if (detect_cnt % 30 == 1 && !detections.empty()) {
        std::cout << "[YOLO DETECT#" << detect_cnt << "] 检测到 " << detections.size() << " 个目标: ";
        for (const auto& d : detections) {
            std::cout << d.class_name << "(" << d.class_id << "," << d.conf << ") ";
        }
        std::cout << std::endl;
    }
    
    return detections;
}

std::vector<YoloDetectorRKNNV2::Detection> YoloDetectorRKNNV2::postprocess_yolov8(const float* output, int orig_w, int orig_h) {
    std::vector<Detection> detections;

    // 输出格式: (1, features, N) 或 (1, N, features)，features = 4 + num_classes
    int num_proposals = output_num_proposals_;
    int num_classes = output_num_features_ - 4;  // 从模型输出维度推导类别数
    if (num_classes <= 0) {
        return detections;
    }
    
    // 提取边界框和类别分数
    std::vector<cv::Rect> boxes;
    std::vector<float> scores;
    std::vector<int> class_ids;

    int conf_pass = 0, cls_filtered = 0;
    float top_score = 0.0f;
    int top_cls = -1;

    for (int i = 0; i < num_proposals; i++) {
        // 提取边界框 (cx, cy, w, h)
        float cx, cy, w, h;
        if (output_is_nhwc_) {
            const float* row = output + i * output_num_features_;
            cx = row[0];
            cy = row[1];
            w  = row[2];
            h  = row[3];
        } else {
            cx = output[0 * num_proposals + i];
            cy = output[1 * num_proposals + i];
            w  = output[2 * num_proposals + i];
            h  = output[3 * num_proposals + i];
        }
        
        // 转换为 (x1, y1, x2, y2)
        float x1 = cx - w * 0.5f;
        float y1 = cy - h * 0.5f;
        float x2 = cx + w * 0.5f;
        float y2 = cy + h * 0.5f;
        
        // 找到最高分数的类别
        float max_score = 0.0f;
        int max_class_id = -1;

        for (int j = 0; j < num_classes; j++) {
            float class_score;
            if (output_is_nhwc_) {
                class_score = output[i * output_num_features_ + (4 + j)];
            } else {
                class_score = output[(4 + j) * num_proposals + i];
            }
            if (class_score > max_score) {
                max_score = class_score;
                max_class_id = j;
            }
        }
        
        // 过滤低分数检测 + 目标类别过滤
        if (max_score >= config_.conf_thresh) {
            conf_pass++;
            if (max_score > top_score) { top_score = max_score; top_cls = max_class_id; }

            // target_classes 过滤
            if (!config_.target_classes.empty()) {
                bool is_target = false;
                for (int tc : config_.target_classes) {
                    if (max_class_id == tc) { is_target = true; break; }
                }
                if (!is_target) { cls_filtered++; continue; }
            }

            // 映射回原图坐标
            x1 = (x1 - pad_x_) * orig_w / (input_width_ - 2 * pad_x_);
            y1 = (y1 - pad_y_) * orig_h / (input_height_ - 2 * pad_y_);
            x2 = (x2 - pad_x_) * orig_w / (input_width_ - 2 * pad_x_);
            y2 = (y2 - pad_y_) * orig_h / (input_height_ - 2 * pad_y_);
            
            // 限制在图像范围内
            x1 = std::max(0.0f, std::min(x1, static_cast<float>(orig_w - 1)));
            y1 = std::max(0.0f, std::min(y1, static_cast<float>(orig_h - 1)));
            x2 = std::max(0.0f, std::min(x2, static_cast<float>(orig_w - 1)));
            y2 = std::max(0.0f, std::min(y2, static_cast<float>(orig_h - 1)));
            
            boxes.emplace_back(static_cast<int>(x1), static_cast<int>(y1), 
                              static_cast<int>(x2 - x1), static_cast<int>(y2 - y1));
            scores.push_back(max_score);
            class_ids.push_back(max_class_id);

        }
    }
    
    // NMS
    std::vector<int> keep_indices = nms(boxes, scores, config_.iou_thresh);
    
    for (int idx : keep_indices) {
        Detection det;
        det.box = boxes[idx];
        det.conf = scores[idx];
        det.class_id = class_ids[idx];
        det.class_name = (class_ids[idx] < static_cast<int>(config_.class_names.size())) ?
                        config_.class_names[class_ids[idx]] : "unknown";
        detections.push_back(det);
    }

    // 调试：每30帧打印一次后处理统计
    static int dbg_frame = 0;
    if (++dbg_frame % 30 == 1) {
        std::cout << "[YOLO-DBG] conf>=" << config_.conf_thresh << ": " << conf_pass
                  << " (top: cls=" << top_cls << " score=" << top_score << ")"
                  << ", cls_filtered=" << cls_filtered
                  << ", NMS_kept=" << keep_indices.size()
                  << ", orig=" << orig_w << "x" << orig_h
                  << ", pad=" << pad_x_ << "," << pad_y_
                  << ", input=" << input_width_ << "x" << input_height_
                  << std::endl;
    }
    
    return detections;
}

std::vector<YoloDetectorRKNNV2::Detection> YoloDetectorRKNNV2::postprocess_multibranch(const float** outputs, int num_outputs, int orig_w, int orig_h) {
    std::vector<Detection> detections;
    
    // YOLOv8 多分支输出格式（RKNN）：
    // 3个尺度：80x80, 40x40, 20x20
    // 每个尺度3个分支：box(64通道DFL), cls(80通道), obj(1通道)
    // 输出顺序：[box0, cls0, obj0, box1, cls1, obj1, box2, cls2, obj2]
    
    struct ScaleInfo {
        int width;
        int height;
        int box_idx;
        int cls_idx;
        int obj_idx;
    };
    
    std::vector<ScaleInfo> scales = {
        {80, 80, 0, 1, 2},   // 80x80
        {40, 40, 3, 4, 5},   // 40x40
        {20, 20, 6, 7, 8}    // 20x20
    };
    
    int num_classes = static_cast<int>(config_.class_names.size());
    if (num_classes <= 0) return detections;
    
    // DFL解码函数（从Python移植）
    auto dfl = [](const float* position, int idx, int grid_size, int reg_max = 16) {
        // position: 64通道，每个坐标用16个分布值表示
        // reg_max = 16, 4个坐标 * 16 = 64通道
        std::array<float, 4> coords;
        
        for (int c = 0; c < 4; c++) {
            // 提取16个分布值
            std::vector<float> dist(16);
            for (int r = 0; r < 16; r++) {
                dist[r] = position[(c * 16 + r) * grid_size + idx];
            }
            
            // Softmax
            float max_val = *std::max_element(dist.begin(), dist.end());
            float sum = 0.0f;
            for (auto& v : dist) {
                v = std::exp(v - max_val);
                sum += v;
            }
            for (auto& v : dist) {
                v /= sum;
            }
            
            // 加权求和
            coords[c] = 0.0f;
            for (int r = 0; r < 16; r++) {
                coords[c] += dist[r] * static_cast<float>(r);
            }
        }
        
        return coords;
    };
    
    std::vector<cv::Rect> boxes;
    std::vector<float> scores;
    std::vector<int> class_ids;
    
    for (const auto& scale : scales) {
        const float* box_data = outputs[scale.box_idx];   // 1x64xWxH
        const float* cls_data = outputs[scale.cls_idx];   // 1x80xWxH
        const float* obj_data = outputs[scale.obj_idx];   // 1x1xWxH
        
        int grid_size = scale.width * scale.height;
        int stride = input_width_ / scale.width;
        
        for (int i = 0; i < grid_size; i++) {
            float obj_conf = obj_data[i];
            if (obj_conf < config_.conf_thresh) continue;
            
            // 找到最高分数的类别
            float max_cls_score = 0.0f;
            int max_class_id = -1;
            
            for (int c = 0; c < num_classes; c++) {
                float cls_score = cls_data[c * grid_size + i];
                if (cls_score > max_cls_score) {
                    max_cls_score = cls_score;
                    max_class_id = c;
                }
            }
            
            float final_score = max_cls_score * obj_conf;
            if (final_score < config_.conf_thresh) continue;
            
            // ✅ 类别过滤（放在 NMS 之前，避免非目标框压制目标框）
            bool is_target = config_.target_classes.empty();
            for (int tc : config_.target_classes) {
                if (max_class_id == tc) { is_target = true; break; }
            }
            if (!is_target) continue;
            
            // DFL解码box坐标
            auto coords = dfl(box_data, i, grid_size, 16);
            float dist_lt_x = coords[0];
            float dist_lt_y = coords[1];
            float dist_rb_x = coords[2];
            float dist_rb_y = coords[3];
            
            // 计算网格坐标
            int grid_x = i % scale.width;
            int grid_y = i / scale.width;
            
            // 转换为绝对坐标（参考Python实现）
            float x1 = (grid_x + 0.5f - dist_lt_x) * stride;
            float y1 = (grid_y + 0.5f - dist_lt_y) * stride;
            float x2 = (grid_x + 0.5f + dist_rb_x) * stride;
            float y2 = (grid_y + 0.5f + dist_rb_y) * stride;
            
            // 映射回原图坐标
            x1 = (x1 - pad_x_) * orig_w / (input_width_ - 2 * pad_x_);
            y1 = (y1 - pad_y_) * orig_h / (input_height_ - 2 * pad_y_);
            x2 = (x2 - pad_x_) * orig_w / (input_width_ - 2 * pad_x_);
            y2 = (y2 - pad_y_) * orig_h / (input_height_ - 2 * pad_y_);
            
            // 限制在图像范围内
            x1 = std::max(0.0f, std::min(x1, static_cast<float>(orig_w - 1)));
            y1 = std::max(0.0f, std::min(y1, static_cast<float>(orig_h - 1)));
            x2 = std::max(0.0f, std::min(x2, static_cast<float>(orig_w - 1)));
            y2 = std::max(0.0f, std::min(y2, static_cast<float>(orig_h - 1)));
            
            boxes.emplace_back(static_cast<int>(x1), static_cast<int>(y1),
                              static_cast<int>(x2 - x1), static_cast<int>(y2 - y1));
            scores.push_back(final_score);
            class_ids.push_back(max_class_id);
        }
    }
    
    // NMS
    std::vector<int> keep_indices = nms(boxes, scores, config_.iou_thresh);
    
    for (int idx : keep_indices) {
        Detection det;
        det.box = boxes[idx];
        det.conf = scores[idx];
        det.class_id = class_ids[idx];
        det.class_name = (class_ids[idx] < config_.class_names.size()) ?
                        config_.class_names[class_ids[idx]] : "unknown";
        detections.push_back(det);
    }
    
    return detections;
}

bool YoloDetectorRKNNV2::detect_best(const cv::Mat& frame, Detection& out) {
    auto detections = detect(frame);
    if (detections.empty()) {
        return false;
    }
    
    // 找到置信度最高的检测
    auto best_it = std::max_element(detections.begin(), detections.end(),
        [](const Detection& a, const Detection& b) {
            return a.conf < b.conf;
        });
    
    out = *best_it;
    return true;
}

bool YoloDetectorRKNNV2::detect_best_class(const cv::Mat& frame, int target_class, Detection& out) {
    auto detections = detect(frame);
    if (detections.empty()) {
        return false;
    }
    
    // 找到指定类别中置信度最高的检测
    Detection best;
    bool found = false;
    
    for (const auto& det : detections) {
        if (det.class_id == target_class && det.conf > best.conf) {
            best = det;
            found = true;
        }
    }
    
    if (found) {
        out = best;
        return true;
    }
    
    return false;
}

std::vector<int> YoloDetectorRKNNV2::nms(const std::vector<cv::Rect>& boxes, const std::vector<float>& scores, float iou_thresh) {
    std::vector<int> indices(scores.size());
    std::iota(indices.begin(), indices.end(), 0);
    
    // 按分数排序
    std::sort(indices.begin(), indices.end(), [&scores](int i1, int i2) {
        return scores[i1] > scores[i2];
    });
    
    std::vector<bool> suppressed(scores.size(), false);
    std::vector<int> keep;
    
    for (size_t i = 0; i < indices.size(); i++) {
        int idx = indices[i];
        if (suppressed[idx]) continue;
        
        keep.push_back(idx);
        
        for (size_t j = i + 1; j < indices.size(); j++) {
            int idx2 = indices[j];
            if (suppressed[idx2]) continue;
            
            if (compute_iou(boxes[idx], boxes[idx2]) > iou_thresh) {
                suppressed[idx2] = true;
            }
        }
    }
    
    return keep;
}

float YoloDetectorRKNNV2::compute_iou(const cv::Rect& box1, const cv::Rect& box2) {
    int x1 = std::max(box1.x, box2.x);
    int y1 = std::max(box1.y, box2.y);
    int x2 = std::min(box1.x + box1.width, box2.x + box2.width);
    int y2 = std::min(box1.y + box1.height, box2.y + box2.height);
    
    if (x2 <= x1 || y2 <= y1) {
        return 0.0f;
    }
    
    int intersection = (x2 - x1) * (y2 - y1);
    int area1 = box1.width * box1.height;
    int area2 = box2.width * box2.height;
    int union_area = area1 + area2 - intersection;
    
    return static_cast<float>(intersection) / union_area;
}

std::vector<std::vector<YoloDetectorRKNNV2::Detection>> YoloDetectorRKNNV2::detect_batch(const std::vector<cv::Mat>& frames) {
    std::vector<std::vector<Detection>> results;
    results.reserve(frames.size());
    
    for (const auto& frame : frames) {
        results.push_back(detect(frame));
    }
    
    return results;
}

} // namespace algorithm
