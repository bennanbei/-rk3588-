#pragma once
#include <string>
#include <vector>
#include <opencv2/opencv.hpp>
#include <rknn_api.h>

namespace algorithm {

class YoloDetectorRKNNV2 {
    
public:
    struct Detection {
        cv::Rect box;
        float conf;
        int class_id;
        std::string class_name;
    };
    
    struct Config {
        float conf_thresh = 0.25f;
        float iou_thresh = 0.45f;
        std::vector<int> target_classes = {8};  // 只检测  boat(8)
        int input_width = 640;
        int input_height = 640;
        bool enable_letterbox = true;
        std::vector<std::string> class_names = {
            "person", "bicycle", "car", "motorbike", "aeroplane", "bus", "train", "truck", "boat", "traffic light",
            "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep", "cow", "elephant",
            "bear", "zebra", "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee", "skis", "snowboard", "sports ball", "kite",
            "baseball bat", "baseball glove", "skateboard", "surfboard", "tennis racket", "bottle", "wine glass", "cup", "fork", "knife",
            "spoon", "bowl", "banana", "apple", "sandwich", "orange", "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "sofa",
            "pottedplant", "bed", "diningtable", "toilet", "tvmonitor", "laptop", "mouse", "remote", "keyboard", "cell phone", "microwave",
            "oven", "toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors", "teddy bear", "hair drier", "toothbrush"
        };
    };

public:
    YoloDetectorRKNNV2() = default;
    explicit YoloDetectorRKNNV2(const Config& cfg);
    ~YoloDetectorRKNNV2();

    bool load_model(const std::string& model_path);

    void set_config(const Config& cfg) { config_ = cfg; }
    Config& get_config() { return config_; }
    
    void set_conf_threshold(float t) { config_.conf_thresh = t; }
    void set_iou_threshold(float t) { config_.iou_thresh = t; }
    void set_target_classes(const std::vector<int>& class_ids) { config_.target_classes = class_ids; }

    std::vector<Detection> detect(const cv::Mat& frame);
    bool detect_best(const cv::Mat& frame, Detection& out);
    
    // 获取指定类别的最佳检测
    bool detect_best_class(const cv::Mat& frame, int target_class, Detection& out);
    
    // 批量检测多帧
    std::vector<std::vector<Detection>> detect_batch(const std::vector<cv::Mat>& frames);

private:
    void release();
    cv::Mat preprocess(const cv::Mat& frame);
    
    // 支持 YOLOv8 标准输出格式 (1, 84, 8400)
    std::vector<Detection> postprocess_yolov8(const float* output, int orig_w, int orig_h);
    
    // 支持多分支输出格式 (9 outputs)
    std::vector<Detection> postprocess_multibranch(const float** outputs, int num_outputs, int orig_w, int orig_h);
    
    // NMS
    std::vector<int> nms(const std::vector<cv::Rect>& boxes, const std::vector<float>& scores, float iou_thresh);
    
    // 计算IoU
    float compute_iou(const cv::Rect& box1, const cv::Rect& box2);

private:
    std::string model_path_;
    Config config_;
    
    rknn_context ctx_ = 0;
    rknn_input_output_num io_num_;
    rknn_tensor_attr* input_attrs_ = nullptr;
    rknn_tensor_attr* output_attrs_ = nullptr;
    
    int input_width_ = 640;
    int input_height_ = 640;
    int num_classes_ = 80;
    float pad_x_ = 0.0f;
    float pad_y_ = 0.0f;
    bool model_loaded_ = false;
    
    // 输出格式检测
    bool is_multibranch_output_ = false;
    int num_outputs_ = 1;
    bool output_is_nhwc_ = false;
    int output_num_proposals_ = 8400;
    int output_num_features_ = 84;
};

} // namespace algorithm
