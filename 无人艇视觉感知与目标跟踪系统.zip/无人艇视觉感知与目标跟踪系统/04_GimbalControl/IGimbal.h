#pragma once

#include <cstdint>

namespace abstract_camer {

// 云台数据包结构体
struct DataPacket {
    float yaw = 0.0f;
    float pitch = 0.0f;
    float roll = 0.0f;
    float distance = 0.0f;
    float zoom_value = 0.0f;
};

class IGimbal {
public:
    virtual ~IGimbal() = default;
    virtual bool start() = 0;
    virtual bool stop() = 0;
    virtual bool is_running() const = 0;
    virtual bool set_angle(double pitch, double yaw) = 0;
    virtual bool get_angle(double& pitch, double& yaw) = 0;
    virtual bool get_distance(double& distance) = 0;
    virtual bool zoom_abs(uint8_t zoom_int) = 0;
    virtual bool zoom_manual(int8_t zoom) = 0;  // -1:缩小 0:停止 1:放大
    virtual bool get_zoom() = 0;
    virtual bool gimbal_turn(int8_t yaw, int8_t pitch) = 0;
    virtual DataPacket latest() const = 0;
    virtual bool center() = 0;  // 归中命令
};

}  // namespace abstract_camer
