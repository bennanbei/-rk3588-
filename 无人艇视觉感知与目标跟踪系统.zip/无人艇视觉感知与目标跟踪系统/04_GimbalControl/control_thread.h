#pragma once

#include <atomic>
#include <chrono>
#include <deque>
#include <memory>
#include <mutex>
#include <thread>

#include "../../abstract_camer/IGimbal.h"
#include "../../algorithm/control/pid_controler.h"
#include "../../algorithm/water_seg/seg_control/seg_control_rknn.h"
#include "../../algorithm/angele_limit/angle_limit.h"
#include "../../algorithm/detection/yolo_detect_rknn_v2.h"
#include "../../algorithm/reid/TargetMatcher.h"
#include "../09_TcpCommunication/tcp_client.h"
#include "track_thread.h"
#include "draw_thread.h"

using PIDController = algorithm::PidControler;

constexpr float CNN_LOCK_THRESHOLD        = 0.35f;  // 初次锁定：降低以适应弱光/远距离船只
constexpr float CNN_TRACK_LOOSE_THRESHOLD = 0.38f;  // 跟踪中高IoU：低阈值保证连贯
constexpr float CNN_TRACK_STRICT_THRESHOLD = 0.48f; // 跟踪中低IoU：稍降防误判
constexpr float IOU_HIGH_THRESHOLD        = 0.30f;  // IoU分界线：高于此值认为移动平缓

namespace algorithm {
class ZOOM_AUTO;
}

namespace worker {

class ControlWorker {
public:
    enum class Mode {
        INITIAL_SEARCH,  // 开局搜索
        TRACKING,        // 跟踪
        MEMORY_MODE,     // 记忆模式（目标短暂丢失）
        IDLE             // 空闲
    };

public:
    ControlWorker(abstract_camer::IGimbal&     gimbal,
                  worker::TrackingWorker&       tracking_worker,
                  algorithm::seg_control_rknn&  seg_controler,
                  PIDController&                yaw_pid,
                  PIDController&                pitch_pid,
                  algorithm::AngleLimit&        angle_limit,
                  algorithm::YoloDetectorRKNNV2& yolo_detector,
                  TargetMatcher&                target_matcher)
        : gimbal_(gimbal),
          tracking_worker_(tracking_worker),
          seg_controler_(seg_controler),
          yaw_pid_(yaw_pid),
          pitch_pid_(pitch_pid),
          angle_limit_(angle_limit),
          yolo_detector_(yolo_detector),
          target_matcher_(target_matcher)
    {}

    ~ControlWorker();

    void start();
    void stop();
    void join();

    bool is_running() const;

    void setMode(Mode mode);
    Mode mode() const;

    void setTargetTrackId(int track_id);
    int  targetTrackId() const;
    int  getTargetTrackId() const { return targetTrackId(); }

    void setDrawWorker(DrawWorker* dw) { draw_worker_ = dw; }
    void setZoomAuto(algorithm::ZOOM_AUTO* za) { zoom_auto_ = za; }

    // TCP 遥测：发送跟踪数据给工控机
    void configureTcp(const std::string& ip, uint16_t port) {
        tcp_client_ = std::make_unique<network::TcpClient>();
        tcp_client_->connect(ip, port);
    }

private:
    // ── 主循环 ──────────────────────────────────────────────
    void run();
    void configurePID();

    // ── 状态处理 ────────────────────────────────────────────
    void handleIdle();
    void handleInitialSearch();
    void handleTracking();
    void handleMemoryMode();

    // ── 状态切换 ────────────────────────────────────────────
    void changeMode(Mode new_mode);

    // ── 通用工具 ────────────────────────────────────────────
    void        stopGimbalAndSleep(int ms);
    void        requestZoomUpdateIfDue();
    static const char* modeToString(Mode mode);

    // ── 跟踪 / 检测辅助 ─────────────────────────────────────
    bool getLatestTrackingResult(worker::TrackingWorker::SharedTrackingResult& result);

    bool findTrackById(const worker::TrackingWorker::SharedTrackingResult& result,
                       int            track_id,
                       const STrack*& selected_track) const;

    bool findStableDetectionCandidate(worker::TrackingWorker::SharedTrackingResult& result,
                                      const STrack*& candidate_track);

    bool isTrackingCandidate(const STrack& track) const;

    // ── CNN 特征匹配校验 ─────────────────────────────────────
    // 调用 TargetMatcher 进行 CNN 特征相似度比对
    static float computeIoU(const cv::Rect& a, const cv::Rect& b);

    // 自适应阈值：根据 IoU 选择宽松/严格阈值
    float adaptiveCNNThreshold(const cv::Rect& current_box) const;

    // ── 占位接口（按硬件实现） ────────────────────────────────
    bool setZoom(double zoom_x);
    bool isZoomReached(double zoom_x) const;
    void enableHorizonPitch(bool enable);
    void enableAutoFocus(bool enable);

private:
    // ── 线程 / 运行控制 ──────────────────────────────────────
    std::atomic<bool>  running_{false};
    std::thread        thread_;
    mutable std::mutex state_mutex_;

    // ── 硬件 / 算法引用 ──────────────────────────────────────
    abstract_camer::IGimbal&    gimbal_;
    worker::TrackingWorker&     tracking_worker_;
    algorithm::seg_control_rknn& seg_controler_;
    PIDController&              yaw_pid_;
    PIDController&              pitch_pid_;
    algorithm::AngleLimit&      angle_limit_;
    algorithm::YoloDetectorRKNNV2& yolo_detector_;
    TargetMatcher&                target_matcher_;
    DrawWorker*                 draw_worker_{nullptr};
    algorithm::ZOOM_AUTO*       zoom_auto_{nullptr};
    std::unique_ptr<network::TcpClient> tcp_client_;  // 工控机TCP发送

    // ── 状态机 ───────────────────────────────────────────────
    Mode mode_{Mode::INITIAL_SEARCH};

    // ── 跟踪目标 ─────────────────────────────────────────────
    int primary_track_id_{-1};

    // ── 搜索参数 ─────────────────────────────────────────────
    int search_direction_{1};
    int search_speed_{6};

    // ── 时间戳 ───────────────────────────────────────────────
    std::chrono::steady_clock::time_point state_enter_time_{};
    std::chrono::steady_clock::time_point memory_phase_enter_time_{};
    std::chrono::steady_clock::time_point lost_start_time_{};
    std::chrono::steady_clock::time_point last_zoom_query_time_{};
    uint64_t                               last_tracking_seq_{0};

    // ── 脉冲占空比累加器（解决执行器死区抖动） ──────────────────
    double yaw_accumulator_{0.0};
    double pitch_accumulator_{0.0};

    // ── 跟踪态帧缓存（无新帧时推缓存帧避免画面冻结） ──────────
    cv::Mat cached_tracking_frame_;

    // ── 自适应CNN校验状态 ───────────────────────────────────
    bool     target_locked_{false};  // 目标身份已确认
    cv::Rect last_track_box_;        // 上一帧已确认的跟踪框（用于IoU计算）
    int      low_iou_strike_{0};     // 低IoU+低CNN连续帧计数，需≥2才允许跳变

    // ── 海天线持久化（避免闪烁） ───────────────────────────
    int last_horizon_y_{-1};         // 上次有效海天线 y 坐标
};

}  // namespace worker