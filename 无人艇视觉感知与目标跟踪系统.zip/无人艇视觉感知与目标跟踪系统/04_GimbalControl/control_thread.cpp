#include "control_thread.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <iostream>
#include <opencv2/opencv.hpp>
#include "../../algorithm/zoom_auto/zoom_auto.h"

using Detection  = algorithm::YoloDetectorRKNNV2::Detection;

namespace worker {

namespace {
constexpr int kIdleSleepMs = 50;
constexpr int kSearchSleepMs = 30;
constexpr int kTrackingSleepMs = 5;
constexpr int kLostRetrySleepMs = 20;
constexpr int kZoomQueryIntervalMs = 200;

// 这里先直接把“6°/s”映射为速度指令 6
// 如果你的协议里 6 不是 6°/s，请改成你自己的换算值

constexpr int8_t kInitialSearchYawCmd = 6;
constexpr int8_t kMemorySearchYawCmd = 6;
constexpr double kInitialSearchZoom = 8;
constexpr int kInitialSearchStableWindow = 10;
constexpr int kInitialSearchStableHits = 5;

constexpr int kTrackingLostTimeoutMs = 3000;
constexpr double kTrackingMaxCommand = 18.0;
constexpr double kCommandDeadband = 1.4;
constexpr int kMinPitchSpeed = 3;
constexpr int kCenterDeadzonePxX = 35;
constexpr int kCenterDeadzonePxY = 35;
constexpr float kSearchSegGain = 0.5f;
constexpr int kSearchPitchLimit = 4;
}  // namespace

ControlWorker::~ControlWorker() {
    stop();
    join();
}

void ControlWorker::start() {
    if (running_.exchange(true)) {
        return;
    }

    if (thread_.joinable()) {
        thread_.join();
    }

    thread_ = std::thread(&ControlWorker::run, this);
}

void ControlWorker::stop() {
    running_.store(false);
    gimbal_.gimbal_turn(0, 0);
}

void ControlWorker::join() {
    if (thread_.joinable()) {
        thread_.join();
    }
}

bool ControlWorker::is_running() const {
    return running_.load();
}

void ControlWorker::setMode(Mode mode) {
    changeMode(mode);
}

ControlWorker::Mode ControlWorker::mode() const {
    std::lock_guard<std::mutex> lock(state_mutex_);
    return mode_;
}

void ControlWorker::setTargetTrackId(int track_id) {
    std::lock_guard<std::mutex> lock(state_mutex_);
    primary_track_id_ = track_id;
}

int ControlWorker::targetTrackId() const {
    std::lock_guard<std::mutex> lock(state_mutex_);
    return primary_track_id_;
}

void ControlWorker::changeMode(Mode new_mode) {
    std::lock_guard<std::mutex> lock(state_mutex_);
    if (mode_ == new_mode) {
        return;
    }

    std::cout << "[ControlWorker] mode change: ";
    switch (mode_) {
        case Mode::INITIAL_SEARCH: std::cout << "INITIAL_SEARCH"; break;
        case Mode::TRACKING:       std::cout << "TRACKING"; break;
        case Mode::MEMORY_MODE:    std::cout << "MEMORY_MODE"; break;
        case Mode::IDLE:           std::cout << "IDLE"; break;
    }
    std::cout << " -> ";
    switch (new_mode) {
        case Mode::INITIAL_SEARCH: std::cout << "INITIAL_SEARCH"; break;
        case Mode::TRACKING:       std::cout << "TRACKING"; break;
        case Mode::MEMORY_MODE:    std::cout << "MEMORY_MODE"; break;
        case Mode::IDLE:           std::cout << "IDLE"; break;
    }
    std::cout << std::endl;

    mode_ = new_mode;
    state_enter_time_ = std::chrono::steady_clock::now();

    if (new_mode == Mode::INITIAL_SEARCH) {
        primary_track_id_ = -1;
        lost_start_time_ = std::chrono::steady_clock::time_point{};
        // 搜索模式：设置推理间隔为 0.3s，提高响应速度
        seg_controler_.set_infer_interval(0.3f);
    }

    if (new_mode == Mode::TRACKING) {
        lost_start_time_ = std::chrono::steady_clock::time_point{};
        target_locked_ = false;   // 进入跟踪态，重新锁目标
        last_track_box_ = cv::Rect{};
        // 跟踪模式：关闭海天线检测
        enableHorizonPitch(false);
    }

    if (new_mode == Mode::MEMORY_MODE) {
        memory_phase_enter_time_ = std::chrono::steady_clock::now();
    }
}

bool ControlWorker::isTrackingCandidate(const STrack& track) const {
    (void)track;
    return true;
}

// ── IoU 计算 ─────────────────────────────────────────
float ControlWorker::computeIoU(const cv::Rect& a, const cv::Rect& b) {
    cv::Rect intersection = a & b;
    if (intersection.area() <= 0) return 0.0f;
    float union_area = static_cast<float>(a.area() + b.area() - intersection.area());
    if (union_area <= 0.0f) return 0.0f;
    return static_cast<float>(intersection.area()) / union_area;
}

// ── 自适应阈值：根据 IoU 选择宽松/严格阈值 ─────────
float ControlWorker::adaptiveCNNThreshold(const cv::Rect& current_box) const {
    if (!target_locked_ || last_track_box_.area() <= 0) {
        // 未锁定：高阈值确保锁对目标
        return CNN_LOCK_THRESHOLD;
    }
    float iou = computeIoU(current_box, last_track_box_);
    if (iou >= IOU_HIGH_THRESHOLD) {
        // 高IoU：跟踪框移动平缓 → 低阈值保连贯
        return CNN_TRACK_LOOSE_THRESHOLD;
    } else {
        // 低IoU：可能换了目标 → 高阈值防错误切换
        return CNN_TRACK_STRICT_THRESHOLD;
    }
}

void ControlWorker::configurePID() {
    yaw_pid_.setGains(0.08, 0.0, 0.02);    // 降低Kp防振荡
    yaw_pid_.setOutputLimits(-15, 15);      // 降低最大输出

    pitch_pid_.setGains(0.10, 0.0, 0.02);   // 降低Kp防振荡
    pitch_pid_.setOutputLimits(-15, 15);     // 降低最大输出
    pitch_pid_.setIntegralLimits(-300, 300);

    std::cout << "[ControlWorker] PID configured (low-gain anti-oscillation)" << std::endl;
}

void ControlWorker::stopGimbalAndSleep(int ms) {
    gimbal_.gimbal_turn(0, 0);
    std::this_thread::sleep_for(std::chrono::milliseconds(ms));
}

void ControlWorker::requestZoomUpdateIfDue() {
    const auto now = std::chrono::steady_clock::now();
    if (last_zoom_query_time_ != std::chrono::steady_clock::time_point{} &&
        std::chrono::duration_cast<std::chrono::milliseconds>(now - last_zoom_query_time_).count() <
            kZoomQueryIntervalMs) {
        return;
    }

    gimbal_.get_zoom();
    last_zoom_query_time_ = now;
}

bool ControlWorker::getLatestTrackingResult(worker::TrackingWorker::SharedTrackingResult& result) {
    if (!tracking_worker_.getResultIfNew(last_tracking_seq_, result)) {
        return false;
    }
    last_tracking_seq_ = result.seq;
    return true;
}

bool ControlWorker::findTrackById(const worker::TrackingWorker::SharedTrackingResult& result,
                                  int track_id,
                                  const STrack*& selected_track) const {
    selected_track = nullptr;
    if (track_id < 0) {
        return false;
    }

    for (const auto& track : result.tracks) {
        if (track.track_id == track_id && track.tlwh.size() >= 4) {
            selected_track = &track;
            return true;
        }
    }
    return false;
}

bool ControlWorker::findStableDetectionCandidate(worker::TrackingWorker::SharedTrackingResult& result,
                                                 const STrack*& candidate_track) {
    candidate_track = nullptr;

    if (!getLatestTrackingResult(result)) {
        return false;
    }

    if (result.frame.empty() || result.tracks.empty()) {
        return false;
    }

    // 用 CNN 相似度在 ByteTrack 轨迹中找最佳匹配
    float best_sim = 0.0f;
    for (const auto& track : result.tracks) {
        if (track.tlwh.size() < 4) continue;
        cv::Rect track_roi(
            static_cast<int>(track.tlwh[0]),
            static_cast<int>(track.tlwh[1]),
            static_cast<int>(track.tlwh[2]),
            static_cast<int>(track.tlwh[3])
        );
        cv::Rect valid_roi = track_roi & cv::Rect(0, 0, result.frame.cols, result.frame.rows);
        if (valid_roi.area() <= 0 || valid_roi.width <= 0 || valid_roi.height <= 0) continue;
        
        cv::Mat roi = result.frame(valid_roi);
        float sim = target_matcher_.computeSimilarity(roi);
        if (sim > best_sim && sim >= CNN_LOCK_THRESHOLD) {
            best_sim = sim;
            candidate_track = &track;
        }
    }

    return candidate_track != nullptr;
}

bool ControlWorker::setZoom(double zoom_x) {
    const int zoom_i = std::clamp(static_cast<int>(std::round(zoom_x)), 1, 10);
    const bool ok = gimbal_.zoom_abs(static_cast<uint8_t>(zoom_i));
    if (ok) {
        gimbal_.get_zoom();
    }
    return ok;
}

bool ControlWorker::isZoomReached(double zoom_x) const {
    const auto packet = gimbal_.latest();
    return std::abs(static_cast<double>(packet.zoom_value) - zoom_x) < 0.2;
}

void ControlWorker::enableHorizonPitch(bool enable) {
    seg_controler_.enable(enable);
}

void ControlWorker::enableAutoFocus(bool enable) {
    // TODO: 按你的IGimbal或其他接口实现

    (void)enable;
}

void ControlWorker::handleIdle() {
    gimbal_.gimbal_turn(0, 0);
    std::this_thread::sleep_for(std::chrono::milliseconds(kIdleSleepMs));
}

void ControlWorker::handleInitialSearch() {
    worker::TrackingWorker::SharedTrackingResult result;
    if (!getLatestTrackingResult(result)) {
        if (!tracking_worker_.getResult(result) || result.frame.empty()) {
            gimbal_.gimbal_turn(search_speed_, 0);
            if (zoom_auto_) {
                zoom_auto_->zoom_auto_rotation();
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(kSearchSleepMs));
            return;
        }
    }

    if (result.frame.empty()) {
        gimbal_.gimbal_turn(search_speed_, 0);
        if (zoom_auto_) {
            zoom_auto_->zoom_auto_rotation();
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(kSearchSleepMs));
        return;
    }

    const auto gimbal_state = gimbal_.latest();
    const bool has_zoom_value = gimbal_state.zoom_value > 0.0f;

    // 检查水天线分割是否启用
    int8_t el_speed = 0;
    if (seg_controler_.is_enabled()) {
        // 开启水天线（分割线程）并喂入当前帧
        enableHorizonPitch(true);
        seg_controler_.submit_frame(result.frame);
        seg_controler_.seg_control_value(result.frame.rows, kSearchSegGain);
        seg_controler_.draw_water_area(result.frame);

        // 将分割输出转换为云台俯仰速度（脉冲占空比，避免硬抬到min_speed导致抖动）
        const double pitch_seg_cmd = static_cast<double>(seg_controler_.get_pitch_speed());
        const int16_t pitch_seg = [&]() -> int16_t {
            if (std::abs(pitch_seg_cmd) < kCommandDeadband) {
                pitch_accumulator_ = 0.0;
                return 0;
            }
            if (std::abs(pitch_seg_cmd) >= static_cast<double>(kMinPitchSpeed)) {
                pitch_accumulator_ = 0.0;
                return static_cast<int16_t>(std::clamp(
                    static_cast<int>(std::round(pitch_seg_cmd)),
                    -static_cast<int>(kTrackingMaxCommand),
                    static_cast<int>(kTrackingMaxCommand)));
            }
            pitch_accumulator_ += std::abs(pitch_seg_cmd);
            if (pitch_accumulator_ >= static_cast<double>(kMinPitchSpeed)) {
                pitch_accumulator_ -= static_cast<double>(kMinPitchSpeed);
                return static_cast<int16_t>(pitch_seg_cmd > 0 ? kMinPitchSpeed : -kMinPitchSpeed);
            }
            return 0;
        }();

        const int16_t limited_pitch = angle_limit_.limitPitchSpeed(gimbal_state.pitch, pitch_seg);
        el_speed = static_cast<int8_t>(std::clamp(
            static_cast<int>(limited_pitch), -kSearchPitchLimit, kSearchPitchLimit));
    }
   
    // 搜索：偏航保持扫描，俯仰由水天线补偿（禁用时俯仰为0）
    gimbal_.gimbal_turn(search_speed_, el_speed);

    if (zoom_auto_) {
        zoom_auto_->zoom_auto_rotation();
    }



    // 1) 直接复用 TrackingWorker 产出的 detections，避免同一帧重复跑YOLO
    if (result.detections.empty()) {
        if (draw_worker_) {
            draw_worker_->push({std::move(result.frame), std::move(result.tracks),
                                {}, -1, "SEARCHING", gimbal_state.zoom_value, has_zoom_value});
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(kSearchSleepMs));
        return;
    }

    // DEBUG: 每30帧打印一次
    static int ctrl_dbg = 0;
    if (++ctrl_dbg % 30 == 1) {
        std::cout << "[CTRL] 收到 " << result.detections.size() << " 个检测: ";
        for (const auto& d : result.detections) {
            std::cout << d.class_name << "(" << d.class_id << "," << d.conf << ") ";
        }
        std::cout << std::endl;
    }

    // 按类别过滤 (boat=8 / mouse=64)
    std::vector<Detection> target_detections;
    for (const auto& det : result.detections) {
        if (det.class_id == 0 || det.class_id == 8 || det.class_id == 64) {
            target_detections.push_back(det);
        }
    }

    if (target_detections.empty()) {
        if (draw_worker_) {
            draw_worker_->push({std::move(result.frame), std::move(result.tracks),
                                std::move(result.detections), -1, "SEARCHING", gimbal_state.zoom_value, has_zoom_value});
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(kSearchSleepMs));
        return;
    }

    // 2) CNN 特征匹配：找与模板库最相似的目标
    auto t_find_start = std::chrono::high_resolution_clock::now();
    MatchScore match = target_matcher_.findTarget(result.frame, target_detections);
    auto t_find_end = std::chrono::high_resolution_clock::now();
    auto find_ms = std::chrono::duration_cast<std::chrono::milliseconds>(t_find_end - t_find_start).count();
    
    std::cout << "[CTRL] CNN匹配: valid=" << match.isValid()
              << " score=" << match.combinedScore
              << " idx=" << match.index
              << " (阈值=" << CNN_LOCK_THRESHOLD << ")"
              << " 耗时=" << find_ms << "ms" << std::endl;

    if (!match.isValid() || match.combinedScore < CNN_LOCK_THRESHOLD) {
        if (draw_worker_) {
            draw_worker_->push({std::move(result.frame), std::move(result.tracks),
                                std::move(result.detections), -1, "SEARCHING", gimbal_state.zoom_value, has_zoom_value});
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(kSearchSleepMs));
        return;
    }

    const Detection& best_detection = target_detections[match.index];
    std::cout << "[ControlWorker] CNN match found: index=" << match.index
              << " similarity=" << match.combinedScore
              << " class_id=" << best_detection.class_id << std::endl;

    // 3) IoU 匹配：CNN 最佳检测框 → ByteTrack 轨迹（得到稳定 track_id）
    auto computeIou = [](const cv::Rect& a, const cv::Rect& b) -> float {
        const cv::Rect inter = a & b;
        if (inter.area() <= 0) return 0.0f;
        const float inter_area = static_cast<float>(inter.area());
        const float union_area = static_cast<float>(a.area() + b.area() - inter.area());
        return union_area > 0.0f ? (inter_area / union_area) : 0.0f;
    };

    const STrack* best_track = nullptr;
    float best_iou = 0.0f;
    constexpr float kMatchIouThresh = 0.30f;

    cv::Rect best_box = best_detection.box & cv::Rect(0, 0, result.frame.cols, result.frame.rows);
    if (best_box.area() <= 0) {
        if (draw_worker_) {
            draw_worker_->push({std::move(result.frame), std::move(result.tracks),
                                std::move(result.detections), -1, "SEARCHING", gimbal_state.zoom_value, has_zoom_value});
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(kSearchSleepMs));
        return;
    }

    for (const auto& track : result.tracks) {
        if (track.tlwh.size() < 4) continue;
        cv::Rect track_box(
            static_cast<int>(track.tlwh[0]),
            static_cast<int>(track.tlwh[1]),
            static_cast<int>(track.tlwh[2]),
            static_cast<int>(track.tlwh[3])
        );
        track_box &= cv::Rect(0, 0, result.frame.cols, result.frame.rows);
        if (track_box.area() <= 0) continue;
        const float iou = computeIou(best_box, track_box);
        if (iou > best_iou) {
            best_iou = iou;
            best_track = &track;
        }
    }

    if (best_track == nullptr || best_iou < kMatchIouThresh) {
        if (draw_worker_) {
            draw_worker_->push({std::move(result.frame), std::move(result.tracks),
                                std::move(result.detections), -1, "SEARCHING", gimbal_state.zoom_value, has_zoom_value});
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(kSearchSleepMs));
        return;
    }

    // 4) CNN 匹配通过 → 锁定主目标并切换到跟踪
    setTargetTrackId(best_track->track_id);
    std::cout << "[ControlWorker] lock target id=" << best_track->track_id
              << " iou=" << best_iou << " cnn_sim=" << match.combinedScore
              << ", switch to TRACKING" << std::endl;
    changeMode(Mode::TRACKING);
}

void ControlWorker::handleTracking() {
    int current_target_track_id = getTargetTrackId();

    if (current_target_track_id < 0) {
        std::cout << "[ControlWorker] invalid target id, back to INITIAL_SEARCH" << std::endl;
        changeMode(Mode::INITIAL_SEARCH);
        stopGimbalAndSleep(kLostRetrySleepMs);
        return;
    }

    // 跟踪时：海天线3s降频推理，辅助视觉标注
    enableHorizonPitch(true);
    seg_controler_.set_infer_interval(3.0f);
    enableAutoFocus(true);

    worker::TrackingWorker::SharedTrackingResult result;
    // 🔥 只用新帧做跟踪逻辑（避免 OSNet 每 5ms 跑一次），无新帧时推缓存帧保持画面流畅
    if (!getLatestTrackingResult(result)) {
        if (draw_worker_ && !cached_tracking_frame_.empty()) {
            const auto gs = gimbal_.latest();
            draw_worker_->push({cached_tracking_frame_.clone(), {},
                                {}, current_target_track_id, "TRACKING",
                                gs.zoom_value, gs.zoom_value > 0.0f});
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(kTrackingSleepMs));
        return;
    }

    // 缓存当前帧用于空转时推图
    result.frame.copyTo(cached_tracking_frame_);

    if (result.tracks.empty()) {
        auto now = std::chrono::steady_clock::now();
        if (lost_start_time_ == std::chrono::steady_clock::time_point{}) {
            lost_start_time_ = now;
        }
        const auto lost_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
            now - lost_start_time_).count();
        if (lost_ms >= kTrackingLostTimeoutMs) {
            std::cout << "[ControlWorker] target lost for 3s, switch to MEMORY_MODE" << std::endl;
            changeMode(Mode::MEMORY_MODE);
            stopGimbalAndSleep(kLostRetrySleepMs);
            return;
        }
        if (draw_worker_) {
            const auto gs = gimbal_.latest();
            draw_worker_->push({std::move(result.frame), std::move(result.tracks),
                                std::move(result.detections), current_target_track_id, "TRACKING(LOST)",
                                gs.zoom_value, gs.zoom_value > 0.0f});
        }
        gimbal_.gimbal_turn(0, 0);
        std::this_thread::sleep_for(std::chrono::milliseconds(kLostRetrySleepMs));
        return;
    }

    const STrack* selected_track = nullptr;
    if (!findTrackById(result, current_target_track_id, selected_track) ||
        selected_track == nullptr ||
        !isTrackingCandidate(*selected_track)) {
        auto now = std::chrono::steady_clock::now();
        if (lost_start_time_ == std::chrono::steady_clock::time_point{}) {
            lost_start_time_ = now;
        }
        const auto lost_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
            now - lost_start_time_).count();
        if (lost_ms >= kTrackingLostTimeoutMs) {
            std::cout << "[ControlWorker] tracking target lost for 3s, switch to MEMORY_MODE"
                      << std::endl;
            changeMode(Mode::MEMORY_MODE);
            stopGimbalAndSleep(kLostRetrySleepMs);
            return;
        }
        if (draw_worker_) {
            const auto gs = gimbal_.latest();
            draw_worker_->push({std::move(result.frame), std::move(result.tracks),
                                std::move(result.detections), current_target_track_id, "TRACKING(LOST)",
                                gs.zoom_value, gs.zoom_value > 0.0f});
        }
        gimbal_.gimbal_turn(0, 0);
        std::this_thread::sleep_for(std::chrono::milliseconds(kLostRetrySleepMs));
        return;
    }

    // 找回目标，清掉丢失计时
    lost_start_time_ = std::chrono::steady_clock::time_point{};

    // ── 构建当前跟踪框（用于IoU判断） ──
    cv::Rect current_box(
        static_cast<int>(selected_track->tlwh[0]),
        static_cast<int>(selected_track->tlwh[1]),
        static_cast<int>(selected_track->tlwh[2]),
        static_cast<int>(selected_track->tlwh[3])
    );

    // ── CNN 身份验证：自适应阈值，防止 ID 抢夺 ──
    const float cnn_id_sim = [&]() -> float {
        cv::Rect valid_roi = current_box & cv::Rect(0, 0, result.frame.cols, result.frame.rows);
        if (valid_roi.area() <= 0 || valid_roi.width <= 0 || valid_roi.height <= 0) {
            return 0.0f;
        }
        cv::Mat roi = result.frame(valid_roi);
        return target_matcher_.computeSimilarity(roi);
    }();

    const float cnn_threshold = adaptiveCNNThreshold(current_box);
    const float iou_with_last = target_locked_ && last_track_box_.area() > 0
                                  ? computeIoU(current_box, last_track_box_) : 0.0f;

    if (cnn_id_sim < cnn_threshold) {
        // 已锁定 + 低IoU + CNN不达标 → 需要连续两帧确认才切记忆模式
        if (target_locked_ && iou_with_last < IOU_HIGH_THRESHOLD) {
            low_iou_strike_++;
            if (low_iou_strike_ >= 2) {
                std::cout << "[ControlWorker] CNN reject 2x (ID switch?): sim=" << cnn_id_sim
                          << " < thr=" << cnn_threshold
                          << " iou=" << iou_with_last
                          << std::endl;
                target_locked_ = false;
                last_track_box_ = cv::Rect{};
                low_iou_strike_ = 0;
                changeMode(Mode::MEMORY_MODE);
                stopGimbalAndSleep(kLostRetrySleepMs);
                return;
            }
            // 第一帧不达标：继续用ByteTrack跟踪，等待第二帧确认
            std::cout << "[ControlWorker] CNN low strike=" << low_iou_strike_
                      << "/2: sim=" << cnn_id_sim
                      << " < thr=" << cnn_threshold
                      << " iou=" << iou_with_last << std::endl;
        } else {
            // 未锁定或高IoU但CNN低：容忍，重置计数器
            low_iou_strike_ = 0;
        }
    } else {
        // CNN通过 → 重置计数器 + 确认/更新锁定状态
        low_iou_strike_ = 0;
        if (!target_locked_) {
            std::cout << "[ControlWorker] CNN lock confirmed: sim=" << cnn_id_sim
                      << " >= " << cnn_threshold << std::endl;
            target_locked_ = true;
        }
        last_track_box_ = current_box;  // 更新已确认框用于下一帧IoU
    }

    // 提前取帧尺寸，之后帧所有权将转移给绘画线程
    const int frameCenterX = result.frame.cols / 2;
    const int frameCenterY = result.frame.rows / 2;

    // 通知绘画线程（move 避免深拷贝）
    if (draw_worker_) {
        // 海天线3s降频推理：draw_water_area 内部有 has_result 检查，每帧调保证持续显示
        seg_controler_.submit_frame(result.frame);
        seg_controler_.draw_water_area(result.frame);
        if (seg_controler_.has_result()) {
            auto cmd = seg_controler_.get_control_command();
            last_horizon_y_ = cmd.horizon_y;
        }
        // 持久化：用上次有效值，避免 horizon_y 在 -1 和有效值之间跳变
        int horizon_y = last_horizon_y_;

        const auto gimbal_state = gimbal_.latest();
        const bool has_zoom_value = gimbal_state.zoom_value > 0.0f;
        draw_worker_->push({std::move(result.frame), std::move(result.tracks),
                            std::move(result.detections), current_target_track_id, "TRACKING", gimbal_state.zoom_value,
                            has_zoom_value, horizon_y});
    }

    cv::Point center(
        static_cast<int>(selected_track->tlwh[0] + selected_track->tlwh[2] * 0.5f),
        static_cast<int>(selected_track->tlwh[1] + selected_track->tlwh[3] * 0.5f)
    );

    const int16_t offsetX = static_cast<int16_t>(center.x - frameCenterX);
    const int16_t offsetY = static_cast<int16_t>(center.y - frameCenterY);

    const double yaw_output   = yaw_pid_.update(0.0, static_cast<double>(offsetX));
    const double pitch_output = pitch_pid_.update(0.0, static_cast<double>(offsetY));

    // ── 脉冲占空比速度映射（sigma-delta 累加器） ──────────────
    // 大误差：直接输出 >= min_speed（正常跟踪）
    // 小误差（0 < |cmd| < min_speed）：累加器攒满 min_speed 才发一次脉冲
    // 死区内：输出 0 并清累加器
    auto pulseSpeed = [](double command, int min_speed, double& accumulator) -> int16_t {
        const double clamped = std::clamp(command, -kTrackingMaxCommand, kTrackingMaxCommand);

        if (std::abs(clamped) < kCommandDeadband) {
            accumulator = 0.0;
            return 0;
        }

        const double abs_cmd = std::abs(clamped);
        if (abs_cmd >= static_cast<double>(min_speed)) {
            accumulator = 0.0;
            int speed = static_cast<int>(std::round(clamped));
            return static_cast<int16_t>(
                std::clamp(speed,
                           -static_cast<int>(kTrackingMaxCommand),
                           static_cast<int>(kTrackingMaxCommand)));
        }

        // 小误差区间：累加器模式
        accumulator += abs_cmd;
        if (accumulator >= static_cast<double>(min_speed)) {
            accumulator -= static_cast<double>(min_speed);
            return static_cast<int16_t>(clamped > 0.0 ? min_speed : -min_speed);
        }
        return 0;
    };

    // 中心静稳区：在目标接近中心时抑制来回修正，减少抖动
    const bool yaw_in_deadzone = std::abs(offsetX) <= kCenterDeadzonePxX;
    const bool pitch_in_deadzone = std::abs(offsetY) <= kCenterDeadzonePxY;

    // 保留你之前的方向定义
    const double yaw_command = yaw_in_deadzone
                                 ? 0.0
                                 : std::clamp(-yaw_output, -kTrackingMaxCommand, kTrackingMaxCommand);
    const double pitch_command = pitch_in_deadzone
                                   ? 0.0
                                   : std::clamp(pitch_output, -kTrackingMaxCommand, kTrackingMaxCommand);

    auto continuousSpeed = [](double command) -> int8_t {
        const double clamped = std::clamp(command, -kTrackingMaxCommand, kTrackingMaxCommand);
        if (std::abs(clamped) < kCommandDeadband) {
            return 0;
        }
        int speed = static_cast<int>(std::round(clamped));
        if (speed == 0) speed = (clamped > 0.0) ? 1 : -1;
        return static_cast<int8_t>(std::clamp(
            speed,
            -static_cast<int>(kTrackingMaxCommand),
            static_cast<int>(kTrackingMaxCommand)));
    };

    const int8_t az_speed = continuousSpeed(yaw_command);
    const int16_t desired_pitch_speed = pulseSpeed(pitch_command, kMinPitchSpeed, pitch_accumulator_);

    const int8_t el_speed = static_cast<int8_t>(desired_pitch_speed);

    // ── TCP 遥测上报（tracking data → 工控机） ────────────
    if (tcp_client_) {
        const auto gs = gimbal_.latest();
        double yaw = 0.0, pitch = 0.0, dist = 0.0;
        gimbal_.get_angle(pitch, yaw);
        gimbal_.get_distance(dist);

        network::TrackingPacket pkt{};
        pkt.offset_x        = offsetX;
        pkt.offset_y        = offsetY;
        pkt.track_id        = static_cast<int16_t>(current_target_track_id);
        pkt.az_speed        = az_speed;
        pkt.el_speed        = el_speed;
        pkt.cnn_sim         = static_cast<float>(cnn_id_sim);
        pkt.gimbal_yaw      = static_cast<float>(yaw);
        pkt.gimbal_pitch    = static_cast<float>(pitch);
        pkt.gimbal_distance = static_cast<float>(dist);
        pkt.zoom_value      = gs.zoom_value;
        pkt.mode            = 2;  // TRACKING
        tcp_client_->send(pkt);
    }

    static int log_counter = 0;
    static uint64_t last_seq = 0;
    const uint64_t seq_delta = (last_seq == 0 || result.seq < last_seq)
                                 ? 0
                                 : (result.seq - last_seq);
    last_seq = result.seq;

    if ((++log_counter % 20) == 0) {
        std::cout << "[ControlWorker] track_id=" << current_target_track_id
                  << " seq=" << result.seq
                  << " seq_delta=" << seq_delta
                  << " offsetX=" << offsetX
                  << " offsetY=" << offsetY
                  << " az_speed=" << static_cast<int>(az_speed)
                  << " el_speed=" << static_cast<int>(el_speed)
                  << " cnn_sim=" << cnn_id_sim
                  << std::endl;
    }

    gimbal_.gimbal_turn(az_speed, el_speed);
    std::this_thread::sleep_for(std::chrono::milliseconds(kTrackingSleepMs));
}

void ControlWorker::handleMemoryMode() {
    constexpr int kMemoryModeTimeoutMs = 5000;

    const auto now = std::chrono::steady_clock::now();
    const auto elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        now - memory_phase_enter_time_).count();

    if (elapsed_ms >= kMemoryModeTimeoutMs) {
        std::cout << "[ControlWorker] memory mode timeout, back to INITIAL_SEARCH" << std::endl;
        changeMode(Mode::INITIAL_SEARCH);
        stopGimbalAndSleep(kLostRetrySleepMs);
        return;
    }

    gimbal_.gimbal_turn(kMemorySearchYawCmd, 0);

    const int tid = targetTrackId();  // 提前声明，后续多处使用

    worker::TrackingWorker::SharedTrackingResult result;
    const bool has_result = getLatestTrackingResult(result) && !result.frame.empty();

    if (!has_result) {
        // 无新帧也推缓存帧，让 DrawWorker 能清理过期跟踪框
        if (draw_worker_ && !cached_tracking_frame_.empty()) {
            const auto gs = gimbal_.latest();
            std::vector<STrack> empty_tracks;
            std::vector<Detection> empty_dets;
            draw_worker_->push({cached_tracking_frame_.clone(), empty_tracks, empty_dets,
                                tid, "MEMORY", gs.zoom_value, gs.zoom_value > 0.0f});
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(kLostRetrySleepMs));
        return;
    }

    if (result.tracks.empty()) {
        // 有帧但无track：也推帧让旧框到期清理
        if (draw_worker_) {
            const auto gs = gimbal_.latest();
            DrawWorker::DrawFrame df;
            df.frame = std::move(result.frame);
            df.tracks = std::move(result.tracks);
            df.detections = std::move(result.detections);
            df.target_track_id = tid;
            df.mode_label = "MEMORY";
            df.zoom_value = gs.zoom_value;
            df.has_zoom = gs.zoom_value > 0.0f;
            df.horizon_y = -1;
            draw_worker_->push(std::move(df));
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(kLostRetrySleepMs));
        return;
    }

    const STrack* found_track = nullptr;
    if (tid >= 0 && findTrackById(result, tid, found_track) && found_track != nullptr) {
        std::cout << "[ControlWorker] target re-found in memory mode, back to TRACKING" << std::endl;
        changeMode(Mode::TRACKING);
        return;
    }

    if (draw_worker_) {
        const auto gimbal_state = gimbal_.latest();
        const bool has_zoom_value = gimbal_state.zoom_value > 0.0f;
        draw_worker_->push({std::move(result.frame), std::move(result.tracks), 
                            std::move(result.detections), tid, "MEMORY",
                            gimbal_state.zoom_value, has_zoom_value});
    }

    std::this_thread::sleep_for(std::chrono::milliseconds(kLostRetrySleepMs));
}

void ControlWorker::run() {
    configurePID();

    const auto now = std::chrono::steady_clock::now();
    state_enter_time_ = now;
    memory_phase_enter_time_ = now;
    lost_start_time_ = std::chrono::steady_clock::time_point{};
    last_zoom_query_time_ = std::chrono::steady_clock::time_point{};

    while (running_.load()) {
        requestZoomUpdateIfDue();
        switch (mode()) {
        case Mode::INITIAL_SEARCH:
            handleInitialSearch();
            break;

        case Mode::TRACKING:
            handleTracking();
            break;

        case Mode::MEMORY_MODE:
            handleMemoryMode();
            break;

        case Mode::IDLE:
            handleIdle();
            break;
        }
    }

    gimbal_.gimbal_turn(0, 0);
    std::cout << "[ControlWorker] thread stopped" << std::endl;
}

}  // namespace worker