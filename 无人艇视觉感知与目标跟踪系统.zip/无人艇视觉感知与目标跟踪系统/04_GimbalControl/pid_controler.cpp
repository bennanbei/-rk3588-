#include "pid_controler.h"
#include <limits>

namespace algorithm {

PidControler::PidControler(double kp, double ki, double kd)
    : kp_(kp)
    , ki_(ki)
    , kd_(kd)
    , proportional_(0.0)
    , integral_(0.0)
    , derivative_(0.0)
    , prev_error_(0.0)
    , integral_sum_(0.0)
    , output_min_(-std::numeric_limits<double>::max())
    , output_max_(std::numeric_limits<double>::max())
    , integral_min_(-std::numeric_limits<double>::max())
    , integral_max_(std::numeric_limits<double>::max())
    , first_run_(true)
{
}

void PidControler::setGains(double kp, double ki, double kd) {
    kp_ = kp;
    ki_ = ki;
    kd_ = kd;
}

void PidControler::setOutputLimits(double min, double max) {
    output_min_ = min;
    output_max_ = max;
}

void PidControler::setIntegralLimits(double min, double max) {
    integral_min_ = min;
    integral_max_ = max;
}

void PidControler::reset() {
    proportional_ = 0.0;
    integral_ = 0.0;
    derivative_ = 0.0;
    prev_error_ = 0.0;
    integral_sum_ = 0.0;
    first_run_ = true;
}

double PidControler::update(double setpoint, double actual_value) {
    auto current_time = std::chrono::steady_clock::now();
    
    if (first_run_) {
        prev_time_ = current_time;
        prev_error_ = setpoint - actual_value;
        first_run_ = false;
        return 0.0;
    }
    
    // 计算时间间隔（秒）
    std::chrono::duration<double> elapsed = current_time - prev_time_;
    double dt = elapsed.count();
    prev_time_ = current_time;
    
    // 防止 dt 为 0
    if (dt <= 0.0) {
        dt = 0.001;
    }
    
    return update(setpoint, actual_value, dt);
}

double PidControler::update(double setpoint, double actual_value, double dt) {
    // 计算误差
    double error = setpoint - actual_value;
    
    // 比例项：P = Kp * error
    proportional_ = kp_ * error;
    
    // 积分项：I = Ki * ∫error dt（梯形积分）
    integral_sum_ += (error + prev_error_) * 0.5 * dt;
    
    // 积分限幅（抗积分饱和）
    integral_sum_ = std::clamp(integral_sum_, integral_min_, integral_max_);
    integral_ = ki_ * integral_sum_;
    
    // 微分项：D = Kd * d(error)/dt
    derivative_ = kd_ * (error - prev_error_) / dt;
    
    // ========== 计算总输出 ==========
    // PID 输出 = P + I + D
    double output = proportional_ + integral_ + derivative_;
    
    // 输出限幅（防止输出过大）
    output = std::clamp(output, output_min_, output_max_);
    
    // 保存当前误差（供下次计算微分用）
    prev_error_ = error;
    
    // ========== 返回控制量（这就是输出！）==========
    return output;  // ← 这里！PID 的输出
}

} // namespace algorithm
