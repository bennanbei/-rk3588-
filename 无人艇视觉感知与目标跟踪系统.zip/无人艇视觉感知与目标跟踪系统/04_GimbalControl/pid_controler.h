#pragma once
#include <chrono>
#include <algorithm>

namespace algorithm {

class PidControler {
public:
    // 构造函数
    PidControler(double kp = 0.0, double ki = 0.0, double kd = 0.0);
    
    // 析构函数
    ~PidControler() = default;
    
    // 设置 PID 增益
    void setGains(double kp, double ki, double kd);
    
    // 设置输出限制
    void setOutputLimits(double min, double max);
    
    // 设置积分限制（抗积分饱和）
    void setIntegralLimits(double min, double max);
    
    // 重置控制器状态
    void reset();
    
    // 更新控制器（自动计算时间间隔）
    double update(double setpoint, double actual_value);
    
    // 更新控制器（手动指定时间间隔）
    double update(double setpoint, double actual_value, double dt);
    
    // 获取各项值（用于调试）
    double getProportional() const { return proportional_; }
    double getIntegral() const { return integral_; }
    double getDerivative() const { return derivative_; }
    double getError() const { return prev_error_; }

private:
    // PID 增益参数
    double kp_;
    double ki_;
    double kd_;
    
    // PID 项
    double proportional_; // 比例项
    double integral_;     // 积分项
    double derivative_;   // 微分项

    // 状态变量
    double prev_error_;   // 上一次误差
    double integral_sum_; // 积分累积和

    // 限制参数
    double output_min_;   // 输出最小值
    double output_max_;   // 输出最大值
    double integral_min_; // 积分项最小值
    double integral_max_; // 积分项最大值
    
    // 时间相关
    std::chrono::steady_clock::time_point prev_time_;
    bool first_run_;
};

} // namespace algorithm