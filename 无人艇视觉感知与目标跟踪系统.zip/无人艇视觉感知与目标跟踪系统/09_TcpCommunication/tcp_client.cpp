#include "tcp_client.h"

#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cstring>
#include <iostream>

namespace network {

TcpClient::~TcpClient() {
    disconnect();
}

void TcpClient::connect(const std::string& ip, uint16_t port) {
    std::lock_guard<std::mutex> lock(mutex_);
    server_ip_   = ip;
    server_port_ = port;
    try_reconnect();
}

void TcpClient::disconnect() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (socket_fd_ >= 0) {
        ::close(socket_fd_);
        socket_fd_ = -1;
    }
    connected_.store(false, std::memory_order_relaxed);
}

bool TcpClient::try_reconnect() {
    if (server_ip_.empty() || server_port_ == 0) {
        return false;
    }

    auto now = std::chrono::steady_clock::now();
    if (now - last_reconnect_attempt_ < kMinReconnectInterval) {
        return connected_.load(std::memory_order_relaxed);
    }
    last_reconnect_attempt_ = now;

    if (socket_fd_ >= 0) {
        ::close(socket_fd_);
        socket_fd_ = -1;
    }

    socket_fd_ = ::socket(AF_INET, SOCK_STREAM, 0);
    if (socket_fd_ < 0) {
        std::cerr << "[TCP] create socket failed: " << strerror(errno) << std::endl;
        return false;
    }

    int flags = ::fcntl(socket_fd_, F_GETFL, 0);
    ::fcntl(socket_fd_, F_SETFL, flags | O_NONBLOCK);

    int opt = 1;
    ::setsockopt(socket_fd_, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt));

    struct sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port   = htons(server_port_);
    if (::inet_pton(AF_INET, server_ip_.c_str(), &addr.sin_addr) <= 0) {
        std::cerr << "[TCP] invalid IP: " << server_ip_ << std::endl;
        ::close(socket_fd_);
        socket_fd_ = -1;
        return false;
    }

    int ret = ::connect(socket_fd_, reinterpret_cast<struct sockaddr*>(&addr), sizeof(addr));
    if (ret < 0 && errno != EINPROGRESS) {
        std::cerr << "[TCP] connect to " << server_ip_ << ":" << server_port_
                  << " failed: " << strerror(errno) << std::endl;
        ::close(socket_fd_);
        socket_fd_ = -1;
        return false;
    }

    ::fcntl(socket_fd_, F_SETFL, flags);

    connected_.store(true, std::memory_order_relaxed);
    std::cout << "[TCP] connected to " << server_ip_ << ":" << server_port_ << std::endl;
    return true;
}

void TcpClient::send(const TrackingPacket& packet) {
    if (connected_.load(std::memory_order_relaxed)) {
        std::lock_guard<std::mutex> lock(mutex_);
        if (socket_fd_ < 0) {
            connected_.store(false, std::memory_order_relaxed);
            return;
        }

        const char* data = reinterpret_cast<const char*>(&packet);
        ssize_t total = sizeof(TrackingPacket);
        ssize_t sent  = 0;

        while (sent < total) {
            ssize_t n = ::send(socket_fd_, data + sent, total - sent, MSG_NOSIGNAL);
            if (n < 0) {
                if (errno == EAGAIN || errno == EWOULDBLOCK) {
                    break;
                }
                std::cerr << "[TCP] send error: " << strerror(errno) << std::endl;
                ::close(socket_fd_);
                socket_fd_ = -1;
                connected_.store(false, std::memory_order_relaxed);
                return;
            }
            sent += n;
        }
        return;
    }

    {
        std::lock_guard<std::mutex> lock(mutex_);
        try_reconnect();
    }
}

} // namespace network
