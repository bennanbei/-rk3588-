#pragma once

#include <atomic>
#include <cstdint>
#include <mutex>
#include <string>
#include <chrono>

namespace network {

/**
 * 工控机 TCP 数据包 — 定长 32 字节二进制协议
 *
 * 接收端（工控机）解析示例（Python）：
 *   import struct
 *   data = sock.recv(32)
 *   pkt = struct.unpack('<hhhbbfffffBB', data)
 *   # offset_x, offset_y, track_id, az_speed, el_speed,
 *   # cnn_sim, gimbal_yaw, gimbal_pitch, gimbal_distance,
 *   # zoom_value, mode, reserved
 */
#pragma pack(push, 1)
struct TrackingPacket {
    int16_t offset_x;        // 目标偏离画面中心 X（px），右正左负
    int16_t offset_y;        // 目标偏离画面中心 Y（px），下正上负
    int16_t track_id;        // 当前跟踪 ID，-1 表示无目标
    int8_t  az_speed;        // 方位角速度命令
    int8_t  el_speed;        // 俯仰角速度命令
    float   cnn_sim;         // CNN 相似度（0~1）
    float   gimbal_yaw;      // 光电球实测偏航角（度）
    float   gimbal_pitch;    // 光电球实测俯仰角（度）
    float   gimbal_distance; // 光电球激光测距（米），0=无效
    float   zoom_value;      // 当前变焦倍率
    uint8_t mode;            // 状态机: 0=IDLE 1=SEARCH 2=TRACKING 3=MEMORY
    uint8_t reserved[3];     // 对齐填充至 32 字节
};
#pragma pack(pop)

static_assert(sizeof(TrackingPacket) == 32, "TrackingPacket must be 32 bytes");

/**
 * TCP 客户端 — 非阻塞发送跟踪数据给工控机
 *
 * 特性：
 *   - 非阻塞连接（失败不阻塞主线程）
 *   - 断线自动重连（最小间隔 3 秒）
 *   - TCP_NODELAY 禁用 Nagle，低延迟
 *   - 发送失败静默丢弃本帧，不影响跟踪主循环
 *
 * 集成方式（在 ControlWorker::handleTracking 中）：
 *   if (tcp_client_) {
 *       TrackingPacket pkt{...};
 *       tcp_client_->send(pkt);
 *   }
 */
class TcpClient {
public:
    TcpClient() = default;
    ~TcpClient();

    TcpClient(const TcpClient&) = delete;
    TcpClient& operator=(const TcpClient&) = delete;

    void connect(const std::string& ip, uint16_t port);
    void send(const TrackingPacket& packet);
    bool is_connected() const { return connected_.load(std::memory_order_relaxed); }
    void disconnect();

private:
    bool try_reconnect();

    std::string server_ip_;
    uint16_t    server_port_{0};
    int         socket_fd_{-1};
    std::atomic<bool> connected_{false};
    mutable std::mutex mutex_;
    std::chrono::steady_clock::time_point last_reconnect_attempt_;
    static constexpr auto kMinReconnectInterval = std::chrono::seconds(3);
};

} // namespace network
